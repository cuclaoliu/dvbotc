/*-----------------------------------------------------
 Header for OptSpec, Option, and classes derived from
 Option.

 prerequisites: <string>, <map>

 Copyright 2005, 2006 Scott McKellar
 All rights reserved
 
 Date       Change
 ---------- -----------------------------------------
 2004/09/24 Initial creation
 2006/01/15 Add declarations to support verbose mode
 2006/01/28 Support default values for StringOpts
 2006/02/18 Support default values for IntOpts
-----------------------------------------------------*/
#ifndef OPTSPEC_H 
#define OPTSPEC_H     

class Remark;
typedef OwningVector< const Remark > RemarkList;

class Option	// Base class
{
	public :

		enum OptType
		{
			OPT_INT,
			OPT_BOOL,
			OPT_STR
		};

		virtual ~Option();

		const std::string & name() const { return name_; }
		void require() { required_ = true; }
		void allow_multiples() { single_ = false; }

		virtual OptType type() const = 0;
		virtual bool has_default() const = 0;
		bool required() const { return required_; }
		bool single() const { return single_; }

	protected :
	
		Option( const std::string & n ) :
			name_( n ), required_( false ), single_( true ) {}

		const static std::string empty_name;
		std::string name_;

	private :

		bool required_;
		bool single_;
};

class BoolOpt : public Option
{
	public :

        BoolOpt( const std::string & n ) :
			Option( n ) {};
		virtual ~BoolOpt();
		virtual OptType type() const;
		virtual bool has_default() const;
};

class IntOpt : public Option
{
	public :
	
		IntOpt( unsigned long min_val, unsigned long max_val,
				unsigned long default_arg, const std::string & n );
		virtual ~IntOpt();

		virtual OptType type() const; 
		virtual bool has_default() const;
		unsigned long min() const { return min_; }
		unsigned long max() const { return max_; }
		unsigned long default_value() const { return default_value_; }


	private :

		unsigned long min_;
		unsigned long max_;
		unsigned long default_value_;
};

class StringOpt : public Option
{
	public :

		StringOpt( unsigned long min, unsigned long max,
				   const std::string & validator_name,
				   const std::string & linkage_name,
				   const std::string & default_arg,
				   const std::string & n );
		virtual ~StringOpt();

		virtual OptType type() const; 
		virtual bool has_default() const;
		unsigned long min_len() const { return min_len_; }
		unsigned long max_len() const { return max_len_; }
		const std::string & validator() const { return validator_; }
		const std::string & linkage() const { return linkage_; }
		const std::string & default_value() const { return default_value_; }
		
	private :

		unsigned long min_len_;
		unsigned long max_len_;
		std::string validator_;
		std::string linkage_;
		std::string default_value_;
};

typedef std::map< const char, const Option * > OptMap;

class OptSpec
{
	public : 

        OptSpec();
		OptSpec( unsigned long min_args, unsigned long max_args );
		~OptSpec();

		// Disable copy constructor and assignment operator by
		// declaring them but not defining them, since an OptSpec
		// owns pointers (via a RemarkList) that we don't
		// want to copy

		OptSpec( const OptSpec & other );
		OptSpec & operator=( const OptSpec & other );

		unsigned long min_args() const { return min_args_; }
		unsigned long max_args() const { return max_args_; }
		const std::string & header() const { return header_; }
		const std::string & header_dir() const { return header_dir_; }
		const std::string & module() const { return module_; }
		const std::string & function() const { return function_; }
		const std::string & structure() const { return structure_; }
		
		const OptMap & opt_map() const { return opt_map_; }
		const RemarkList & remark_list() const { return remark_list_; }

		int load( std::istream & in );

	private :

		unsigned long min_args_;
		unsigned long max_args_;

        std::string header_;
		std::string header_dir_;
		std::string module_;
		std::string function_;
		std::string structure_;

		OptMap opt_map_;
		RemarkList remark_list_;
};

std::string & pathname( const std::string & path, const std::string & name,
	std::string & pathname );

int cxx_header( const OptSpec & spec );
int c_header( const OptSpec & spec );
int cxx_func( const OptSpec & spec );
int c_func( const OptSpec & spec );

// Functions to change default extensions

void set_cxx_hdr_ext( const char * ext );
void set_cxx_ext( const char * ext );
void set_c_hdr_ext( const char * ext );
void set_c_ext( const char * ext );

namespace aargh
{
	extern bool aargh_verbose;
	inline bool verbose() { return aargh_verbose; }
	int hdr_remarks( const OptSpec & spec, std::ostream & out );
	int impl_remarks( const OptSpec & spec, std::ostream & out );
	const char * generator_name();
};

#endif
