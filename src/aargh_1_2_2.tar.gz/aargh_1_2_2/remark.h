/*----------------------------------------------------
 Desc    : Header for Remark class and derived classes
 Author  : Scott McKellar
 Notes   :

A remark represents a chunk of text to be incorporated into
a comment block at the top of a file.  There are three types
of Remarks:

TextRemark -- literal text
FileRemark -- reference to the contents of an external file
CopyrightRemark -- copyright notice

 Copyright 2006 Scott McKellar
 All Rights reserved
 
 Date       Change
 ---------- -----------------------------------------
 2006/03/04 Initial creation
 ---------------------------------------------------*/

#ifndef REMARK_H
#define REMARK_H

class Remark
{
	public :

		// A remark may belong in the header file, the
		// implementation file, or both.
		
		enum Home
		{
			HDR = 1,
			IMPL = 2,
			BOTH = 3
		};

		virtual ~Remark();
		Home home() const { return home_; }
		virtual void output( std::ostream & out ) const = 0;


	protected :

		explicit Remark( Home h ) : home_( h ) {}
		
	private :

		Home home_;
};

class TextRemark : public Remark
{
	public :

		TextRemark( Home h ) :
			Remark( h ) {}
		TextRemark( Home h, const char * s ) :
			Remark( h ), text_( s ? s : "" ) {}
		TextRemark( const TextRemark & other ) :
			Remark( other.home() ), text_( other.text_ ) {}
		virtual ~TextRemark();

		void swap( std::string & s ) { text_.swap( s ); }
		virtual void output( std::ostream & out ) const;

	private :

		std::string text_;
};


class FileRemark : public Remark
{
	public :

		FileRemark( Home h, const char * s ) :
			Remark( h ), filename_( s ) {}
		FileRemark( const FileRemark & other ) :
			Remark( other.home() ), filename_( other.filename_ ) {}
		virtual ~FileRemark();

//		const std::string & filename() const { return filename_; }
		int load();  // Read the file into the buffer
		virtual void output( std::ostream & out ) const;

	private :

		std::string filename_;
		std::string buffer_;
};

class Copyright : public Remark
{
	public :

		Copyright( Home h, const char * s ) :
			Remark( h ), author_( s ) {}
		Copyright( const Copyright & other ) :
				Remark( other.home() ), author_( other.author_ ) {}
		virtual ~Copyright();

//		const std::string & filename() const { return filename_; }
		virtual void output( std::ostream & out ) const;

	private :

		std::string author_;
};

inline std::ostream & operator<< ( std::ostream & out, const Remark & remark )
{
	remark.output( out );
	return out;
}

#endif
