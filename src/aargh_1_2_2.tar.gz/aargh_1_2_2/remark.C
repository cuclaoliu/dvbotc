/*----------------------------------------------------
 Desc    : Implementation of Remark an related classes
 Author  : Scott McKellar
 Notes   : 

 This program is free software; you can redistribute it and/or
 modify it under the terms of version 2 of the GNU General
 Public License as published by the Free Software Foundation.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor,
 Boston, MA  02110-1301, USA.

 Copyright 2006 Scott McKellar
 All Rights reserved
 
 Date       Change
 ---------- -----------------------------------------
 2006/03/04 Initial creation
 ---------------------------------------------------*/
#include <iostream>
#include <fstream>
#include <string>
#include <tinyxml.h>
#include "remark.h"

namespace std {}
using namespace std;

Remark::~ Remark() {}

/*---------------------------------------------------*/

TextRemark::~TextRemark() {}

void TextRemark::output( ostream & out ) const
{
	out << text_;
}

/*---------------------------------------------------*/

FileRemark::~FileRemark() {}

int FileRemark::load()
{
	const size_t BUFLEN = 512;
	char buffer[ BUFLEN ];

	// Open the file
	
	ifstream file( filename_.c_str() );
	if( ! file )
	{
		cerr << "Unable to open comment file "
			 << filename_ << '\n';
		return 1;
	}

	// Load the file into a local buffer
	
	string tempbuf;

	while( file )
	{
		file.read( buffer, BUFLEN );
		size_t count = file.gcount();
		if( count > 0 )
			tempbuf.append( buffer, buffer + count );
		else
			break;
	}

	// Check for IO errors
	
	if( ! file.eof() )
	{
		cerr << "Error reading comment file "
			 << filename_ << '\n';
		return 1;
	}

	// So far so good.  Load the buffer.

	buffer_.swap( tempbuf );
	
	return 0;
}

void FileRemark::output( ostream & out ) const
{
	// To do: open file, copy it to output stream
	
	out << buffer_;
}

/*---------------------------------------------------*/

Copyright::~Copyright() {}

void Copyright::output( ostream & out ) const
{
	char year[ 5 ] = "";
	
	time_t time_t_now = time( NULL );
	if( time_t_now != (time_t) -1 )
	{
		struct tm * pTm_now = localtime( &time_t_now );
		if( ! strftime ( year, sizeof( year ), "%Y", pTm_now ) )
			year[ 0 ] = '\0';  // Unlikely: failure of strftime()
	}	
	
	out << " Copyright " << author_ << ' ' << year << " All rights reserved\n";
}
