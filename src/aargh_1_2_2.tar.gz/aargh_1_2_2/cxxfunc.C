/*---------------------------------------------------------------------
 Desc    : Code generator to write C++ functions
		   for Opts class (possibly under a different name)
 Author  : Scott McKellar
 Notes   : 

 Copyright 2005, 2006 Scott McKellar
 All rights reserved
 
 This program is free software; you can redistribute it and/or
 modify it under the terms of version 2 of the GNU General
 Public License as published by the Free Software Foundation.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor,
 Boston, MA  02110-1301, USA.

 Date       Change
 ---------- -----------------------------------------------------------
 2005/05/14 Initial creation
 2006/01/07 Add default extension to file name
 2006/01/15 Emit messages in verbose mode
 2006/01/28 Apply defaults to string arguments; add extension to
            header file names as needed
 2006/02/18 Apply default values to IntOpts
 --------------------------------------------------------------------*/

#include <cstdlib>
#include <ctime>
#include <climits>
#include <string>
#include <map>
#include <vector>
#include <set>
#include <iostream>
#include <fstream>
#include "ownvec.h"
#include "optspec.h"

namespace std {}
using namespace std;

namespace {

#ifndef AARGH_CXX_HDR_EXT
#define AARGH_CXX_HDR_EXT "h"
#endif

const char * default_hdr_extension = AARGH_CXX_HDR_EXT;

#ifndef AARGH_CXX_EXT
#define AARGH_CXX_EXT "C"
#endif

const char * default_extension = AARGH_CXX_EXT;

const char * structure;

int write_initializer( ostream & out, const OptSpec & spec );
int write_function( ostream & out, const OptSpec & spec );
int declare_variables( ostream & out, const OptSpec & spec );
int assign_defaults( ostream & out, const OptSpec & spec );
int make_optstring( const OptSpec & spec, string & optstring );
int write_letter_cases( ostream & out, const OptSpec & spec );
int write_boolean_branch( ostream & out, const Option & opt );
int write_integer_branch( ostream & out, const IntOpt & opt,
	char letter );
int write_string_branch( ostream & out, const StringOpt & opt,
	char letter );
int write_required_checks( ostream & out, const OptSpec & spec );
int write_arg_check( ostream & out, const OptSpec & spec );

} //end namespace

/***************************************************************************
 Set default extension for C++ source files (or reset to default default)
 Returns: nothing
 ***************************************************************************/
void set_cxx_ext( const char * ext )
{
	if( ext && *ext )
		default_extension = ext;
	else
		default_extension = AARGH_CXX_EXT;
}

/***************************************************************************
 Write a C++ Implementation file
 Returns: 0 if successful, non-zero otherwise
 ***************************************************************************/
int cxx_func( const OptSpec & spec )
{
	int rc = 0;

	const char * filename;
	string filename_str;
	if( spec.module().empty() )
		filename = "opts.C";
	else
	{
		// Find the basename

		filename = spec.module().c_str();
		const char * basename = strrchr( filename, '/' );
		if( basename )
			++basename;
		else
			basename = filename;

		// Look for a period
		
		if( ! strchr( basename, '.' ) )
		{
			// No period found -- add an extension
			
			filename_str = filename;
			filename_str += '.';
			filename_str += default_extension;
			filename = filename_str.c_str();
		}
	}
	
	// cout << "Function file name: " << filename << '\n';

	ofstream out( filename );
	if( out.fail() )
	{
		cerr << "Unable to open output function file "
			 << filename << '\n';
		return 1;
	}

	if( aargh::verbose() )
		cout << "Writing implementation file " << filename << '\n';
	
	if( spec.structure().empty() )
		structure = "Opts";
	else
		structure = spec.structure().c_str();

	// Write a comment block at the top of the file
	
	if( aargh::impl_remarks( spec, out ) )
	{
		cerr << "Unable to write comment block\n";
		return 1;
	}

	const OptMap & map = spec.opt_map();
	const OptMap::const_iterator map_end = map.end();
	OptMap::const_iterator iter = map.begin();

	// Decide whether to #include certain headers

	bool vector_needed = false; // whether to #include <vector>
	bool stdlib_needed = false; // whether to #include <stdlib.h>
	bool errno_needed  = false; // whether to #include <errno.h>
	bool ctype_needed  = false; // whether to #include <ctype.h>

	while( iter != map_end )
	{
		const Option * pOpt = iter->second;

		if( ! pOpt->single() )
			vector_needed = true;

		if( Option::OPT_STR == pOpt->type() )

			// placeholder in case we ever need another header
			// for strings (we already #include <string> in
			// the generated header, if we need one)

			; 
		else if( Option::OPT_INT == pOpt->type() )
		{
			stdlib_needed = true;
			errno_needed  = true;
			ctype_needed  = true;
		}
		++iter;
	}

	// #include headers as needed

	if( stdlib_needed )
		out << "#include <stdlib.h>\n";

	if( errno_needed )
		out << "#include <errno.h>\n";

	if( ctype_needed )
		out << "#include <ctype.h>\n";

	if( vector_needed )
		out << "#include <vector>\n";

	// include some other headers

	out << "#include <iostream>\n";
	out << "#include <unistd.h>\n";
	out << '\n';

	// include the generated header file

	{
		string header( spec.header() );
		if( header.empty() )
			header = "opts.h";
		else
		{
			if( ! strchr( header.c_str(), '.' ) )
			{
				header += '.';
				header += default_hdr_extension;
			}
		}
		
		out << "#include \"" << header << "\"\n\n";
	}

	// tweak namespaces

	out << "namespace std {}\n";
	out << "using namespace std;\n\n";

	// write the initializer function

	rc = write_initializer( out, spec );

	// write the function

	if( 0 == rc )
		rc = write_function( out, spec );

	return rc;
}

namespace {
	
/*---------------------------------------------------------------------
 Desc    : Write a function to initialize the class instance
 Returns : 0 if successful, otherwise 1
 --------------------------------------------------------------------*/
int write_initializer( ostream & out, const OptSpec & spec )
{
	int rc = 0;

	// Write function header

	out << "void " << structure
		<< "::initialize()\n{\n";

	// Initialize each data member (except for "populated")

	out << "\tnew_argc_ = 0;\n";
	out << "\tnew_argv_ = NULL;\n\n";

	const OptMap & map = spec.opt_map();
	OptMap::const_iterator iter = map.begin();
	const OptMap::const_iterator map_end = map.end();

	while( iter != map_end && 0 == rc )
	{
		const Option * pOpt = iter->second;
		if( NULL == pOpt )
		{
			cerr << "Fatal error in write_initializer(): "
				 << "null pointer to Option" << endl;
			rc = 1;
			break;
		}
		switch( pOpt->type() )
		{
			case Option::OPT_BOOL :
				out << '\t' << pOpt->name() << "_ = false;\n";
				break;
			case Option::OPT_INT :
				out << '\t' << pOpt->name() << "_found_ = false;\n";
				if( pOpt->single() )
					out << '\t' << pOpt->name() << "_ = 0;\n";
				else
					out << '\t' << pOpt->name() << "_.clear();\n";

				break;
			case Option::OPT_STR :
				out << '\t' << pOpt->name() << "_found_ = false;\n";
				if( pOpt->single() )
					out << '\t' << pOpt->name() << "_.erase();\n";
				else
					out << '\t' << pOpt->name() << "_.clear();\n";

				break;
			default :
				break;
		}

		++iter;
	}

	// close function

	out << "}\n\n";

	return rc;
}

/*---------------------------------------------------------------------
 Desc    : Write a function definition
 Returns : 0 if successful, otherwise 1
 --------------------------------------------------------------------*/
int write_function( ostream & out, const OptSpec & spec )
{
	int rc = 0;

	// Write the function header

	const char * func_name;
	if( spec.function().empty() )
		func_name = "get";
	else
		func_name = spec.function().c_str();

	out << "int " << structure << "::" << func_name 
		<< "( int argc, char * argv[] )\n{\n";

	// Declare local variables

	out << "\tint rc = 0; /* return code */\n";
	rc = declare_variables( out, spec );
	if( rc != 0 )
		return rc;
	out << '\n';

	// Initialize data members as needed

	out << "\t// Initialize data members as needed\n\n";

	out << "\tif( populated )\n";
	out << "\t\tinitialize();\n";
	out << "\telse\n";
	out << "\t\tpopulated = true;\n\n";

	// Assign any default values

	rc = assign_defaults( out, spec );
	if( rc != 0 )
		return rc;
	
	// Suppress error messages from getopt()

	out << "\t// Suppress error messages from getopt()\n\n";
	out << "\topterr = 0;\n\n";

	// Build an optstring for getopts(); use it to
	// define valid option characters

	string optstring;
	make_optstring( spec, optstring );

	out << "\t// Define valid option characters\n\n";
	out << "\tconst char optstring[] = \""
		<< optstring << "\";\n\n";

	// Write a loop for examining each option

	out << "\t// Examine command line options\n\n";

	out << "\tint opt;\n";
	out << "\twhile( ( opt = getopt( argc, argv, "
		   "optstring ) ) != -1 )\n\t{\n";

	// Write case structure, branching on option letter

	out << "\t\tswitch( opt )\n\t\t{\n";
	rc = write_letter_cases( out, spec );
	if( rc != 0 )
		return rc;

	out << "\t\t} // end switch\n";
	out << "\t} // end while\n\n";

	// Write code to verify that required
	// options were supplied

	rc = write_required_checks( out, spec );
	if( rc != 0 )
		return rc;

	// Write code to check the number of non-option arguments

	rc = write_arg_check( out, spec );

	// Close the function

	out << "\treturn rc;\n";
	out << "}\n";

	return rc;
}

/*---------------------------------------------------------------------
 Desc    : Declare a series of local variables related to the
		   various options
 Returns : 0 if successful, otherwise 1
 --------------------------------------------------------------------*/
int declare_variables( ostream & out, const OptSpec & spec )
{
	int rc = 0;
	bool tail_needed = false;

	const OptMap & map = spec.opt_map();
	OptMap::const_iterator iter = map.begin();
	const OptMap::const_iterator map_end = map.end();

	iter = map.begin();
	while( iter != map_end && 0 == rc )
	{
		const Option * pOpt = iter->second;
		if( NULL == pOpt )
		{
			cerr << "Fatal error in declare_variables(): "
				 << "null pointer to Option" << endl;
			rc = 1;
			break;
		}
		switch( pOpt->type() )
		{
			case Option::OPT_BOOL :
				break;
			case Option::OPT_INT :
				tail_needed = true;
				out << "\tunsigned long " << pOpt->name()
					<< "_value = 0;\n";
				break;
			case Option:: OPT_STR :
				break;
			default :
				cerr << "Fatal error in declare_variables(): "
					 << "unrecognized option type "
					 << pOpt->type() << endl;
				rc = 1;
				break;
		}
		++iter;
	}

	if( tail_needed )
		out << "\tchar * tail = NULL;\n";

	return rc;
}

/*---------------------------------------------------------------------
 Desc    : Apply any default values
 Returns : 0 if successful, otherwise 1
 --------------------------------------------------------------------*/
int assign_defaults( ostream & out, const OptSpec & spec )
{
	int rc = 0;
	bool commented = false;
	
	const OptMap & map = spec.opt_map();
	OptMap::const_iterator iter = map.begin();
	const OptMap::const_iterator map_end = map.end();

	iter = map.begin();
	while( iter != map_end && 0 == rc )
	{
		const Option * pOpt = iter->second;
		if( NULL == pOpt )
		{
			cerr << "Fatal error in assign_defaults(): "
					<< "null pointer to Option" << endl;
			rc = 1;
			break;
		}
		else if( pOpt->has_default() )
		{
			if( ! commented )
			{
				out << "\t// Apply any default values\n\n";
				commented = true;
			}
			
			switch( pOpt->type() )
			{
				case Option::OPT_BOOL :
					// This shouldn't happen; ignore it
					break;
				case Option::OPT_INT :
				{
					const IntOpt * pInt =
						dynamic_cast< const IntOpt * >( pOpt );
					if( ! pInt )
					{
						cerr << "Fatal error in assign_defaults(): "
								"Can't downcast to IntOpt\n";
						return 1;
					}

					// Having downcast to an IntOpt, apply default

					out << "\t" << pInt->name() << "_ = "
							<< pInt->default_value() << ";\n";
					break;
				}
				case Option:: OPT_STR :
				{
					const StringOpt * pStr =
						dynamic_cast< const StringOpt * >( pOpt );
					if( ! pStr )
					{
						cerr << "Fatal error in assign_defaults(): "
								"Can't downcast to StringOpt\n";
						return 1;
					}

					// Having downcast to a StringOpt, apply default

					out << "\t" << pStr->name() << "_ = \""
						<< pStr->default_value() << "\";\n";
					break;
				}
				default :
					cerr << "Fatal error in assign_defaults(): "
						    "unrecognized option type "
						 << pOpt->type() << endl;
					rc = 1;
					break;
			}
		}
		++iter;
	}

	if( commented )
		out << '\n';

	return rc;
}

/*---------------------------------------------------------------------
 Desc    : construct an optstring for getopts(), inserting colons as 
		   needed to denote options with arguments
 Returns : 0 if successful, otherwise 1
 --------------------------------------------------------------------*/
int make_optstring( const OptSpec & spec, string & optstring )
{
	int rc = 0;
	string s( ":" );

	const OptMap & map = spec.opt_map();
	OptMap::const_iterator iter = map.begin();
	const OptMap::const_iterator map_end = map.end();

	iter = map.begin();
	while( iter != map_end && 0 == rc )
	{
		// Append option letter to optstring

		s += iter->first;

		// For anything but a boolean argument, append a colon
		// to signify that an argument is required

		const Option * pOpt = iter->second;
		if( NULL == pOpt )
		{
			cerr << "Fatal error in make_optstring(): "
				 << "null pointer to Option" << endl;
			rc = 1;
			break;
		}
		if( Option::OPT_BOOL != pOpt->type() )
			s += ":";

		++iter;
	}
	
	optstring.swap( s );
	return rc;
}

/*---------------------------------------------------------------------
 Desc    : Write a series of cases, one for each option letter
 Returns : 0 if successful, otherwise 1
 --------------------------------------------------------------------*/
int write_letter_cases( ostream & out, const OptSpec & spec )
{
	int rc = 0;

	const OptMap & map = spec.opt_map();
	OptMap::const_iterator iter = map.begin();
	const OptMap::const_iterator map_end = map.end();

	iter = map.begin();
	while( iter != map_end && 0 == rc )
	{
		const Option * pOpt = iter->second;
		if( NULL == pOpt )
		{
			cerr << "Fatal error in write_letter_cases(): "
				 << "null pointer to Option" << endl;
			rc = 1;
			break;
		}

		out << "\t\t\tcase '" << iter->first
			<< "' :   // Get " << pOpt->name() << "\n";

		// Write the handler for whichever kind of option

		switch( pOpt->type() )
		{
			case Option::OPT_BOOL :
				rc = write_boolean_branch( out, *pOpt );
				break;
			case Option::OPT_INT :
				rc = write_integer_branch( out, 
					 *(dynamic_cast< const IntOpt *>( pOpt )), 
					 iter->first );
				break;
			case Option::OPT_STR :
				rc = write_string_branch( out, 
					 *(dynamic_cast< const StringOpt *>( pOpt )), 
					 iter->first );
				break;
			default :
				cerr << "Fatal error in write_letter_cases(): "
						"unrecognized option type" << endl;
				rc = 1;
				break;
		}

		out << "\t\t\t\tbreak;\n";

		++iter;
	}

	// Code for missing argument

	out << "\t\t\tcase ':' : // Missing argument\n";
	out << "\t\t\t\tcerr << \"Required argument missing on '-\"\n";
	out << "\t\t\t\t     << static_cast< char >( optopt ) \n";
	out << "\t\t\t\t	 << \"' option\\n\";\n";
	out << "\t\t\t\trc = 1;\n";
	out << "\t\t\t\tbreak;\n";

	// Code for invalid option

	out << "\t\t\tcase '?' : // Invalid option\n";
	out << "\t\t\t\tcerr << \"Invalid option '-\"\n";
	out << "\t\t\t\t     << static_cast< char >( optopt ) \n";
	out << "\t\t\t\t	 << \"' on command line\\n\";\n";
	out << "\t\t\t\trc = 1;\n";
	out << "\t\t\t\tbreak;\n";

	// Code for none of the above

	out << "\t\t\tdefault :  // Programmer error\n";
	out << "\t\t\t\tcerr << \"Internal error: unexpected value '-\"\n";
	out << "\t\t\t\t     << static_cast< char >( optopt ) \n";
	out << "\t\t\t\t	 << \"' of optopt\\n\";\n";
	out << "\t\t\t\trc = 1;\n";
	out << "\t\t\t\tbreak;\n";

	return rc;
}

/*---------------------------------------------------------------------
 Desc    : Write the treatment of a boolean option
 Returns : 0 if successful, otherwise 1
 --------------------------------------------------------------------*/
int write_boolean_branch( ostream & out, const Option & opt )
{
	int rc = 0;

	out << "\t\t\t\t" << opt.name() << "_ = true;\n";

	return rc;
}

/*---------------------------------------------------------------------
 Desc    : Write the treatment of an integer option
 Returns : 0 if successful, otherwise 1
 --------------------------------------------------------------------*/
int write_integer_branch( ostream & out, const IntOpt & opt,
	char letter )
{
	int rc = 0;

	// Declare a char ptr for use by strtoul()

	if( opt.single() )
	{
		// Make sure we only accept one instance of the option

		out << "\t\t\t\tif( " << opt.name() << "_found_ )\n";
		out << "\t\t\t\t{\n";
		out << "\t\t\t\t\tcerr << \"Only one occurrence of -"
			<< letter << " option allowed\\n\";\n";
		out << "\t\t\t\t\trc = 1;\n";
		out << "\t\t\t\t\tbreak;\n";
		out << "\t\t\t\t}\n";
	}

	out << "\t\t\t\t" << opt.name() << "_found_ = true;\n\n";

	// Translate string into long integer, 
	// and check for errors

	// Skip past white space, complain about negative 
	// value if first non-white character is '-'

	out << "\t\t\t\t// Skip white space; check for negative\n\n";

	out << "\t\t\t\twhile( isspace( (unsigned char) *optarg ) )\n";
	out << "\t\t\t\t\t++optarg;\n\n";

	out << "\t\t\t\tif( '-' == *optarg )\n";
	out << "\t\t\t\t{\n";
	out << "\t\t\t\t\tcerr << \"Negative argument not allowed for \"\n";
	out << "\t\t\t\t\t     << \"-" << letter 
		<< " option: \\\"\" << optarg << \"\\\"\\n\";" 
	 	<< '\n';
	out << "\t\t\t\t\trc = 1;\n";
	out << "\t\t\t\t\tbreak;\n";
	out << "\t\t\t\t}\n\n";

	// Convert option argument to numeric value

	out << "\t\t\t\t// Convert to numeric value\n\n";

	out << "\t\t\t\terrno = 0;\n";
	out << "\t\t\t\t" << opt.name() << "_value = "
		   "strtoul( optarg, &tail, 10 );\n";
	
	out << "\t\t\t\tif( *tail != '\\0' )\n";
	out << "\t\t\t\t{\n";
	out << "\t\t\t\t\tcerr << \"Invalid or non-numeric argument to \"\n";
	out << "\t\t\t\t\t     << \"-" << letter 
		<< " option: \\\"\" << optarg << \"\\\"\\n\";" 
		   << '\n';
	out << "\t\t\t\t\trc = 1;\n";
	out << "\t\t\t\t\tbreak;\n";
	out << "\t\t\t\t}\n";

	out << "\t\t\t\telse if( errno != 0 )\n";
	out << "\t\t\t\t{\n";
	out << "\t\t\t\t\tcerr << \"Too large argument to \"\n";
	out << "\t\t\t\t\t     << \"-" << letter 
		<< " option: \\\'\" << optarg << \"\\\"\\n\";" 
		   << '\n';
	out << "\t\t\t\t\trc = 1;\n";
	out << "\t\t\t\t\tbreak;\n";
	out << "\t\t\t\t}\n\n";

	// Compare value to minimum and maximum values

	if( opt.min() > 0 || opt.max() < ULONG_MAX )
		out << "\t\t\t\t// Check for values out of bounds\n\n";

	if( opt.min() > 0 )
	{
		out << "\t\t\t\tif( " << opt.name() << "_value < "
			<< opt.min() << "UL )\n";
		out << "\t\t\t\t{\n";
		out << "\t\t\t\t\tcerr << \"Argument to \"\n";
		out << "\t\t\t\t\t\t << \"-" << letter 
			<< " option \\\"\" << optarg\n" 
			<< "\t\t\t\t\t\t << \"\\\" "
			<< "is less than minimum\\n\";" 
			<< '\n';
		out << "\t\t\t\t\trc = 1;\n";
		out << "\t\t\t\t\tbreak;\n";
		out << "\t\t\t\t}\n\n";
	}

	if( opt.max() < ULONG_MAX )
	{
		out << "\t\t\t\tif( " << opt.name() << "_value > "
			<< opt.max() << "UL )\n";
		out << "\t\t\t\t{\n";
		out << "\t\t\t\t\tcerr << \"Argument to \"\n";
		out << "\t\t\t\t\t\t << \"-" << letter 
			<< " option \\\"\" << optarg \n" 
			<< "\t\t\t\t\t\t << \"\\\" "
			<< "exceeds maximum allowed value\\n\";" 
		    << '\n';
		out << "\t\t\t\t\trc = 1;\n";
		out << "\t\t\t\t\tbreak;\n";
		out << "\t\t\t\t}\n\n";
	}

	// To do: call validator, if any
	// (Validators not implemented for IntOptions)

	// If multiples are allowed, append value to vector

    if( opt.single() ) 
		out << "\t\t\t\t" << opt.name() << "_ = " 
			<< opt.name() << "_value;\n\n";
	else
		out << "\t\t\t\t" << opt.name()
			<< "_.push_back( " << opt.name() 
			<< "_value );\n\n";

	return rc;
}

/*---------------------------------------------------------------------
 Desc    : Write the treatment of a string option
 Returns : 0 if successful, otherwise 1
 --------------------------------------------------------------------*/
int write_string_branch( ostream & out, const StringOpt & opt,
	char letter )
{
	int rc = 0;

	if( opt.single() )
	{
		// Make sure we only accept one instance of the option

		out << "\t\t\t\tif( " << opt.name() << "_found_ )\n";
		out << "\t\t\t\t{\n";
		out << "\t\t\t\t\tcerr << \"Only one occurrence of -"
			<< letter << " option allowed\\n\";\n";
		out << "\t\t\t\t\trc = 1;\n";
		out << "\t\t\t\t\tbreak;\n";
		out << "\t\t\t\t}\n";
	}
	out << "\t\t\t\t" << opt.name() << "_found_ = true;\n\n";

	// Compare length to minimum and maximum lengths

	if( opt.min_len() > 0 || opt.max_len() < ULONG_MAX )
		out << "\t\t\t\t// Check for too long or too short\n\n";

	if( opt.min_len() > 0 )
	{
		out << "\t\t\t\tif( strlen( optarg ) < "
			<< opt.min_len() << "UL )\n";
		out << "\t\t\t\t{\n";
		out << "\t\t\t\t\tcerr << \"Argument to \"\n";
		out << "\t\t\t\t\t     << \"-" << letter 
			<< " option \\\"\" << optarg \n" 
			<< "\t\t\t\t\t\t << \"\\\" "
			<< "is less than the minimum length\\n\";" 
			<< '\n';
		out << "\t\t\t\t\trc = 1;\n";
		out << "\t\t\t\t\tbreak;\n";
		out << "\t\t\t\t}\n\n";
	}

	if( opt.max_len() < ULONG_MAX )
	{
		out << "\t\t\t\tif( strlen( optarg ) > "
			<< opt.max_len() << "UL )\n";
		out << "\t\t\t\t{\n";
		out << "\t\t\t\t\tcerr << \"Argument to \"\n";
		out << "\t\t\t\t\t     << \"-" << letter 
			<< " option \\\"\" << optarg \n" 
			<< "\t\t\t\t\t\t << \"\\\" "
			<< "is more than the maximum length\\n\";" 
			<< '\n';
		out << "\t\t\t\t\trc = 1;\n";
		out << "\t\t\t\t\tbreak;\n";
		out << "\t\t\t\t}\n\n";
	}

	// To do: call validator, if any

	if( ! opt.validator().empty() )
	{
		out << "\t\t\t\t// Call validator function\n\n";
		out << "\t\t\t\tif( " << opt.validator()
				<< "( optarg ) )\n";
		out << "\t\t\t\t{\n";
		out << "\t\t\t\t\tcerr << \"Argument to \"\n";
		out << "\t\t\t\t\t     << \"-" << letter
				<< " option \\\"\" << optarg \n"
				<< "\t\t\t\t\t\t << \"\\\" "
				<< "is invalid\\n\";"
				<< '\n';
		out << "\t\t\t\t\trc = 1;\n";
		out << "\t\t\t\t}\n\n";
	}

	// If multiples are allowed, append value to vector

    if( opt.single() ) 
		out << "\t\t\t\t" << opt.name() << "_ = optarg;\n";
	else
		out << "\t\t\t\t" << opt.name()
			<< "_.push_back( string( optarg ) );\n";

	return rc;
}

/*---------------------------------------------------------------------
 Desc    : Write code to verify that each required option was
		   provided
 Returns : 0 if successful, otherwise 1
 --------------------------------------------------------------------*/
int write_required_checks( ostream & out, const OptSpec & spec )
{
	int rc = 0;

	const OptMap & map = spec.opt_map();
	OptMap::const_iterator iter = map.begin();
	const OptMap::const_iterator map_end = map.end();

	bool first_required = true;
	iter = map.begin();
	while( iter != map_end && 0 == rc )
	{
		const Option * pOpt = iter->second;

		if( pOpt->required() )
		{
			if( first_required )
			{
				out << "\t// See if required options were supplied\n\n";
				first_required = false;
			}

			out << "\tif( ! " << pOpt->name() << "_found_ )\n\t{\n";
			out << "\t\tcerr << \"Required option -"
				<< iter->first
				<< " not provided on command line\\n\";\n";
			out << "\t\trc = 1;\n\t}\n\n";
		}

		++iter;
	}

	return rc;
}

/*---------------------------------------------------------------------
 Desc    : Write code to verify that each required option was
		   provided
 Returns : 0 if successful, otherwise 1
 --------------------------------------------------------------------*/
int write_arg_check( ostream & out, const OptSpec & spec )
{
	int rc = 0;

	// Sanity check

	out << "\tif( optind > argc )\n\t{\n";
	out << "\t\t// This should never happen!\n\n";
	out << "\t\tcerr << \"Program error: found more arguments "
		   "than expected\\n\";\n";
	out << "\t\trc = 1;\n";
	out << "\t}\n";
	out << "\telse\n\t{\n";

	out << "\t\t// Calculate new_argcv_ and new_argc_ to reflect\n";
	out << "\t\t// the number of arguments consumed\n\n";
	out << "\t\tnew_argc_ = argc - optind + 1;\n";
	out << "\t\tnew_argv_ = argv + optind - 1;\n";

	if( spec.max_args() == 0 )
	{
		// Disallow all arguments beyond options

		out << "\n\t\tif( new_argc_ > 0 )\n\t\t{\n";
		out << "\t\t\tcerr << \"No command line arguments allowed "
			   "beyond options\\n\";\n";
		out << "\t\t\trc = 1;\n";
		out << "\t\t}\n";
	}
	else
	{
		if( spec.min_args() > 0 )
		{
			// Enforce minimum number of arguments

			out << "\n\t\tif( static_cast< unsigned long >( new_argc_ ) < " << spec.min_args() + 1
				<< "UL )\n\t\t{\n";
			out << "\t\t\tcerr << \"Not enough arguments "
				   "beyond options; \"\n"
				   "\t\t\t\t    \"must be at least " 
				<< spec.min_args() << "\\n\";\n";
			out << "\t\t\trc = 1;\n";
			out << "\t\t}\n";
		}

		if( spec.max_args() < ULONG_MAX )
		{
			// Enforce maximum number of arguments

			out << "\n\t\tif( static_cast< unsigned long >( new_argc_ ) > " << spec.max_args() + 1
				<< "UL )\n\t\t{\n";
			out << "\t\t\tcerr << \"Too many arguments "
				   "beyond options; \"\n"
				   "\t\t\t\t    \"must be no more than " 
				<< spec.max_args() << "\\n\";\n";
			out << "\t\t\trc = 1;\n";
			out << "\t\t}\n";
		}
	}

	out << "\t}\n\n";
	return rc;
}

} // end namespace
