/*---------------------------------------------------------------------
 Desc    : Code generator to write C++ header files
		   for Opts class (possibly under a different name)
 Author  : Scott McKellar
 Notes   : 

 Copyright 2005, 2006 Scott McKellar
 All rights reserved
 
 This program is free software; you can redistribute it and/or
 modify it under the terms of version 2 of the GNU General
 Public License as published by the Free Software Foundation.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor,
 Boston, MA  02110-1301, USA.

 Date       Change
 ---------- -----------------------------------------------------------
 2005/10/08 Initial creation
 2006/01/07 Add default extension to file name
 2006/01/15 Emit messages in verbose mode
 2006/04/09 Support separate header directory
--------------------------------------------------------------------*/

#include <cstdlib>
#include <ctime>
#include <string>
#include <map>
#include <vector>
#include <set>
#include <iostream>
#include <fstream>
#include "ownvec.h"
#include "optspec.h"

namespace std {}
using namespace std;

namespace {
	
#ifndef AARGH_C_HDR_EXT
#define AARGH_C_HDR_EXT "h"
#endif

const char * default_extension = AARGH_C_HDR_EXT;

const char * structure;

void make_guard( const string & filename, string & guard );
int  declare_node( ofstream & out, const Option & opt );
int  make_declaration( ostream & out, const OptSpec & spec );

} // end namespace

/***************************************************************************
 Set default extension for C header files (or reset to default default)
 Returns: nothing
 ***************************************************************************/
void set_c_hdr_ext( const char * ext )
{
	if( ext && *ext )
		default_extension = ext;
	else
		default_extension = AARGH_C_HDR_EXT;
}

int c_header( const OptSpec & spec )
{
	int rc = 0;

	// Determine the header name, adding an extension as needed
	
	string hdr_name = spec.header();
	if( hdr_name.empty() )
		hdr_name = "opts.h";
	else
	{
		// Find the basename

		const char * basename = strrchr( hdr_name.c_str(), '/' );
		if( basename )
			++basename;
		else
			basename = hdr_name.c_str();

		// If there is no period, add an extension

		if( ! strchr( basename, '.' ) )
		{
			hdr_name += '.';
			hdr_name += default_extension;
		}
	}
	
	string filename;  // For fully qualified file name
	pathname( spec.header_dir(), hdr_name, filename );

	ofstream out( filename.c_str() );
	if( out.fail() )
	{
		cerr << "Unable to open output header file "
			 << filename << '\n';
		return 1;
	}

	if( aargh::verbose() )
		cout << "Writing header file " << filename << '\n';
	
	if( spec.structure().empty() )
		structure = "Opts";
	else
		structure = spec.structure().c_str();

	// Write a comment block at the top of the file
	
	if( aargh::hdr_remarks( spec, out ) )
	{
		cerr << "Unable to write comment block\n";
		return 1;
	}

	// Open a compilation guard

	{
		string guard;
		make_guard( filename, guard );

		out << "#ifndef " << guard
			<< "\n#define " << guard << "\n\n";
	}

	const OptMap & map = spec.opt_map();
	const OptMap::const_iterator map_end = map.end();
	OptMap::const_iterator iter = map.begin();

	// For each option for which multiples are allowed:
	// declare a node to be used in a linked list

	while( iter != map_end )
	{
		const Option * pOpt = iter->second;

		if( ! pOpt->single() && declare_node( out, *pOpt ) )
			return 1;

		++iter;
	}

	// write the struct declaration and validator prototypes

	rc = make_declaration( out, spec );

	// Close the compilation guard

	out << "\n#endif\n";

	return rc;
}

namespace {

/*---------------------------------------------------------------------
 Desc    : Given a file name, construct a macro name to be used to
		   avoid multiple inclusions.

		   Raise letters to upper case; keep digits and upper case
		   unchanged; change everthing else to an underscore.  Add
		   "_GUARD" at the end.
 Returns : nothing
 --------------------------------------------------------------------*/
void make_guard( const string & filename, string & guard )
{
	const char * s = filename.c_str();

	string temp_guard;

	while( *s )
	{
		char c = static_cast< unsigned char>( *s );
		if( islower( c ) )
			temp_guard += toupper( c );
		else if( isalnum( c ) )
			temp_guard += c;
		else
			temp_guard += '_';

		++s;
	}

	temp_guard += "_GUARD";

	guard.swap( temp_guard );
}

/***************************************************************************
 Declare a struct to be used as a node in a linked list,
 for an option for which multiples are allowed
 Returns: nothing
 ***************************************************************************/
int declare_node( ofstream & out, const Option & opt )
{
	out << "struct " << opt.name() << "_node\n{\n";

	// Declare linkage pointer
	
	out << "\tstruct " << opt.name() << "_node * pNext;\n";

	// Declare a variable to hold the contents
	
	if( Option::OPT_STR == opt.type() )
		out << "\tchar * value;\n";
	else if( Option::OPT_INT == opt.type() )
		out << "\tunsigned long value;\n";
	else
	{
		cerr << "declare_node: Unrecognized option type\n";
		return 1;
	}
	
	out << "};\n\n";

	// Declare a typedef

	out << "typedef struct " << opt.name() << "_node "
		<< opt.name() << "_node;\n\n";
	
	return 0;
}

/*---------------------------------------------------------------------
 Desc    : Write a declaration of the specified class
 Returns : 0 if successful, otherwise 1
 --------------------------------------------------------------------*/
int make_declaration( ostream & out, const OptSpec & spec )
{
	out << "struct " << structure << "\n{\n";

	// Declare members

	out << "\tint new_argc;\n";
	out << "\tchar ** new_argv;\n\n";

	const OptMap & map = spec.opt_map();
	OptMap::const_iterator iter = map.begin();
	const OptMap::const_iterator map_end = map.end();

	bool clear_needed = false;
	
	while( iter != map_end )
	{
		const Option * pOpt = iter->second;

		out << "\t";
		switch( pOpt->type() )
		{
			case Option::OPT_BOOL :
				// use int as boolean
				
				out << "int " << pOpt->name() << ";\n";
				break;
			case Option::OPT_STR  :
				if( pOpt->single() )
					out << "char * " << pOpt->name() << ";\n";
				else
				{
					clear_needed = true;
					out << pOpt->name() << "_node * "
						<< pOpt->name() << "_list;\n";
				}
				break;
			case Option::OPT_INT  :
				if( pOpt->single() )
					out << "unsigned long " << pOpt->name() << ";\n";
				else
				{
					clear_needed = true;
					out << pOpt->name() << "_node * "
						<< pOpt->name() << "_list;\n";
				}
				break;
			default :
				break;
		}

		// Add a flag for presence/absence of argument

		if( Option::OPT_BOOL != pOpt->type() )
			out << "\tint " << pOpt->name()
				<< "_found;\n";

		++iter;
	}

	out << "};\n\n";

	// Declare a tyddpedef

	out << "typedef struct " << structure << " " << structure << ";\n\n";

	// Declare the function for parsing the command line

	out << "#ifdef __cplusplus\nextern \"C\" {\n";
	out << "#endif\n\n";

	{
		string func_name;
		if( spec.function().empty() )
		{
			func_name = "get_";
			func_name += structure;
		}
		else
			func_name = spec.function();

		out << "int " << func_name
				<< "( int argc, char * argv[], "
				<< structure << " * pOpts );\n";
	}
	if( clear_needed )
	{
		// Declare a function for deallocating the linked lists

		out << "void clear_" << spec.structure() << "( struct "
			<< spec.structure() << " * pOpts );\n";
	}

	// Declare any validator functions

	// Create a set of function names so that we can
	// avoid declaring the same validator twice

	set< string > func_set;
	pair< set< string >::iterator, bool > set_result;

	iter = map.begin();
	bool validator_declared = false;
	
	while( iter != map_end )
	{
		const Option * pOpt = iter->second;

		const StringOpt * pStr =
			dynamic_cast< const StringOpt *>( pOpt );

		if( pStr && ! pStr->validator().empty() )
		{
			set_result = func_set.insert( pStr->validator() );
			if( set_result.second )
			{
				// Succeeded in inserting the function name,
				// hence we hadn't inserted it before, hence
				// we haven't declared the function yet,
				// so we can declare it now...

				if( ! validator_declared )
				{
					out << "\n/* Declare validator function(s) */\n\n";
					validator_declared = true;
				}
				
				out << "int " << pStr->validator()
					<< "( const char * arg );\n";
			}
		}

		++iter;
	}

	out << "\n#ifdef __cplusplus\n};\n#endif\n";

	return 0;
}

} // end namespace
