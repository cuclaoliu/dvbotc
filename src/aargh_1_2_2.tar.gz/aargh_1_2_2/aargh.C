/*----------------------------------------------------
 Desc    : Generate code for parsing command line
 Author  : Scott McKellar
 Notes   : Assumes availability of UNIX-style getopt()

 Copyright 2005, 2006 Scott McKellar
 All Rights reserved

 This program is free software; you can redistribute it and/or
 modify it under the terms of version 2 of the GNU General
 Public License as published by the Free Software Foundation.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor,
 Boston, MA  02110-1301, USA.

Date       Change
 ---------- -----------------------------------------
 2004/09/24 Initial creation
 2006/01/01 Add branch for generating C
 2006/01/07 Set default extension(s) if so requested
 2006/01/15 Support verbose mode
 ---------------------------------------------------*/
#include <cstdlib>
#include <cstdio>
#include <string>
#include <stdexcept>
#include <iostream>
#include <fstream>
#include <map>
#include <vector>
#include "aargh_opts.h"
#include "ownvec.h"
#include "optspec.h"

namespace std {};
using namespace std;

namespace aargh
{
	bool aargh_verbose = false;
};

namespace {
int logical_main( int argc, char * argv[] );
}

/*----------------------------------------------------
 Desc    : Return name of this program, with current
 		   version number.  This way we can update
 		   the version number in a single, centralized
 		   location.
 Returns : pointer to string literal
 ---------------------------------------------------*/
const char * aargh::generator_name()
{
	return "aargh 1.2";
}

/*----------------------------------------------------
 Desc    : Top level function; exception-catching
		   wrapper.
 Returns : EXIT_SUCCESS or EXIT_FAILURE
 ---------------------------------------------------*/
int main( int argc, char * argv[] )
{
	try
	{
		return logical_main( argc, argv );
	}
	catch( const exception & excp )
	{
		cerr << argv[ 0 ] << ": " << excp.what() << '\n';
		return EXIT_FAILURE;
	}
	catch( ... )
	{
		cerr << argv[ 0 ] << ": Unexpected exception caught\n";
		return EXIT_FAILURE;
	}
}

namespace
{

/*----------------------------------------------------
 Desc    : Top-level but one.
 Returns : EXIT_SUCCESS or EXIT_FAILURE.
 ---------------------------------------------------*/
int logical_main( int argc, char * argv[] )
{
	int rc = EXIT_SUCCESS;
	OptSpec spec;
	Opts opts;

	rc = opts.get( argc, argv );
	if( rc != 0 )
		return EXIT_FAILURE;

	if( opts.verbose() )
		aargh::aargh_verbose = true;

	// Open input file; if no file name is specified on
	// the command line, use standard input.

	istream * pIn = NULL;

	char ** new_argv = opts.new_argv();

	if( opts.new_argc() < 1 || '\0' == *new_argv[ 1 ] )
		pIn = &cin;
	else
	{
		static ifstream in( new_argv[ 1 ] );
		if( in.fail() )
		{
			cerr << "Unable to open input file "
				 << new_argv[ 1 ] << '\n';
			rc = EXIT_FAILURE;
		}
		else
			pIn = &in;
	}

	// Load the specification from the input file

	if( EXIT_SUCCESS == rc )
		rc = spec.load( *pIn );

	// For future expansion: branch to different code
	// generators depending on the target language

	bool C = false;

	if( opts.lang() == "C" )
		C = true;
	else if( opts.lang() != "C++" )
	{
		cerr << argv[ 0 ] << ": Language \""
			<< opts.lang() << "\" not supported\n";
		return EXIT_FAILURE;
	}

	if( 0 == rc )
	{
		if( C )
		{
			// Generate C

			if( aargh::verbose() )
				cout << "----\nGenerating C\n";
			
			// Apply default extensions if so specified
			// on the command line

			if( opts.hdr_extension_found() )
				set_c_hdr_ext( opts.hdr_extension().c_str() );

			if( opts.extension_found() )
				set_c_ext( opts.extension().c_str() );

			rc = c_header( spec );
			if( 0 == rc )
				rc = c_func( spec );
		}
		else
		{
			// Generate C++
			
			if( aargh::verbose() )
				cout << "----\nGenerating C++\n";
			
			// Apply default extensions if so specified
			// on the command line

			if( opts.hdr_extension_found() )
				set_cxx_hdr_ext( opts.hdr_extension().c_str() );

			if( opts.extension_found() )
				set_cxx_ext( opts.extension().c_str() );

			rc = cxx_header( spec );
			if( 0 == rc )
				rc = cxx_func( spec );
		}
	}
	
	return rc;
}

} // end namespace
