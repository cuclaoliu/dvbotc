/*----------------------------------------------------
 Desc    : Load <Remarks> aggregate into a vector of
           pointers to Remarks
 Author  : Scott McKellar
 Notes   : 

 This program is free software; you can redistribute it and/or
 modify it under the terms of version 2 of the GNU General
 Public License as published by the Free Software Foundation.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor,
 Boston, MA  02110-1301, USA.
 
 Copyright 2006 Scott McKellar
 All Rights reserved
 
 Date       Change
 ---------- -----------------------------------------
 2006/03/05 Initial creation
 ---------------------------------------------------*/

#include <memory>
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <tinyxml.h>
#include "ownvec.h"
#include "optspec.h"
#include "remark.h"
#include "expenv.h"

namespace std {};
using namespace std;

namespace aargh
{
	int get_remarks( const TiXmlElement & aggregate, RemarkList & list );
}

namespace {

int get_text_remark( const TiXmlElement & element, RemarkList & list );
int get_file_remark( const TiXmlElement & element, RemarkList & list );
int get_copyright( const TiXmlElement & element, RemarkList & list );

} // end namespace

/***************************************************************************
 Load <Remarks> into a vector of pointers to Remarks
 Returns: 0 if successful, non-zero otherwise
 ***************************************************************************/
int aargh::get_remarks( const TiXmlElement & aggregate, RemarkList & list )
{
	int rc = 0;
	const TiXmlNode * pChild = aggregate.FirstChild();

	{
		// No attributes allowed
		
		const TiXmlAttribute * pAttr = aggregate.FirstAttribute();
		if( pAttr != NULL )
		{
			cerr << "Unexpected attribute in \"Remarks\" element\n";
			return 1;
		}
	}

	while( pChild && 0 == rc )
	{
		switch( pChild->Type() )
		{
			case TiXmlNode::ELEMENT :
			{
				// Downcast node ptr to element pointer

				const TiXmlElement * pElement =
					pChild->ToElement();
				if( ! pElement )
				{
					cerr << "Internal error: unable to convert "
							"Remarks node pointer to element pointer\n";
					return 1;
				}

				const char * value = pElement->Value();

				if( ! strcmp( value, "Text" ) )
					rc = get_text_remark( *pElement, list );
				else if( ! strcmp( value, "File" ) )
					rc = get_file_remark( *pElement, list );
				else if( ! strcmp( value, "Copyright" ) )
					rc = get_copyright( *pElement, list );
				else
				{
					cerr << "Unexpected \"" << value << "\" element "
							"within Remarks aggregate\n";
					return 1;
				}
				break;
			}
			case TiXmlNode::TEXT :
			{
				cerr << "Unexpected text within Remarks aggregate\n";
				return 1;
			}
			default  :  // ignore other types of nodes
				break;
		} // end switch

		pChild = pChild->NextSibling();
	}
	
	return rc;
};

namespace {
	
/***************************************************************************
 Load a Text aggregate into a TextRemark; append to the list
 Returns: 0 if successful, non-zero otherwise
 ***************************************************************************/
int get_text_remark( const TiXmlElement & element, RemarkList & list )
{
	int rc = 0;
	Remark::Home home = Remark::BOTH;
	bool which_found = false;

	const TiXmlAttribute * pAttr = element.FirstAttribute();

	// Loop through the attributes until we have
	// seen them all (or found an error)

	while( pAttr )
	{
		const char * attr_name = pAttr->Name();

		if( NULL == attr_name )
		{
			cerr << "Unable to get attribute name for Text element\n";
			return 1;
		}
		else if( ! strcmp( attr_name, "which" ) )
		{
			if( which_found )
			{
				cerr << "Multiple \"which\" attributes found "
						"in Text element\n";
				rc = 1;
			}
			which_found = true;

			const char * s = pAttr->Value();

			if( ! s )
			{
				cerr << "Unable to get value of \"which\" attribute "
						"in Text element\n";
				return 1;
			}
			else if( ! strcmp( s, "implementation" ) )
				home = Remark::IMPL;
			else if( ! strcmp( s, "header" ) )
				home = Remark::HDR;
			else if( ! strcmp( s, "both" ) )
				home = Remark::BOTH;
			else
			{
				cerr << "Invalid value for \"which\" attribute "
						"in Text element\n";
				rc = 1;
			}
		}
		else
		{
			cerr << "Unrecognized attribute \"" << attr_name
					<< "\" in Copyright element\n";
			return 1;
		}

		pAttr = pAttr->Next();
	} // end for

	// Get text.  There may be multiple segements of text separated by
	// XML comments, so we concatenate them as we go.
	
	const TiXmlNode * pChild = element.FirstChild();
	string text;
	
	while( pChild )
	{
		switch( pChild->Type() )
		{
			case TiXmlNode::ELEMENT :
			{
				cerr << "Unexpected element within Text aggregate\n";
				rc = 1;
				break;
			}
			case TiXmlNode::TEXT :
			{
				// Downcast to a TiXmlText
				
				const TiXmlText * pText = pChild->ToText();
				if( NULL == pText )
				{
					cerr << "Internal error: Unable to downcast to TiXmlText *\n";
					return 1;
				}

				// Append the contents to our text buffer

				const char * s = pText->Value();

				if( s && *s )
				{
					if( '\n' == *s ) // skip a single leading newline
						++s;
					text += s;
				}

				break;
			}
			case TiXmlNode::COMMENT :
				break;	// ignore comment
			default :
			{
				cerr << "Unexpected content within Text aggregate\n";
				rc = 1;
				break;
			}
		} // end switch
		
		pChild = pChild->NextSibling();
	} // end while

	if( 0 == rc )
	{
		if( aargh::verbose() )
			cout << "Loaded text remark\n";

		// Construct a TextRemark and add it to the list
		
		auto_ptr< TextRemark > apText( new TextRemark( home ) );
		apText->swap( text );
		list.push_back(	apText.get() );
		apText.release();  // No exceptions?  Clear auto_ptr...
	}

	return rc;
}

/***************************************************************************
 Load a File aggregate into a FileRemark; append to the list
 Returns: 0 if successful, non-zero otherwise
 ***************************************************************************/
int get_file_remark( const TiXmlElement & element, RemarkList & list )
{
	int rc = 0;
	Remark::Home home;
	const char * filename = NULL;
	string filename_str;
	bool which_found = false;

	const TiXmlAttribute * pAttr = element.FirstAttribute();
	if( NULL == pAttr )
	{
		cerr << "File element has no attributes\n";
		cerr << element << '\n';
		return 1;
	}

	// Loop through the attributes until we have
	// seen them all (or found an error)

	while( pAttr )
	{
		const char * attr_name = pAttr->Name();

		if( NULL == attr_name )
		{
			cerr << "Unable to get attribute name for File element\n";
			return 1;
		}
		else if( ! strcmp( attr_name, "which" ) )
		{
			if( which_found )
			{
				cerr << "Multiple \"which\" attributes found "
						"in File element\n";
				rc = 1;
			}
			which_found = true;

			const char * s = pAttr->Value();

			if( ! s )
			{
				cerr << "Unable to get value of \"which\" attribute "
						"in File element\n";
				return 1;
			}
			else if( ! strcmp( s, "implementation" ) )
				home = Remark::IMPL;
			else if( ! strcmp( s, "header" ) )
				home = Remark::HDR;
			else if( ! strcmp( s, "both" ) )
				home = Remark::BOTH;
			else
			{
				cerr << "Invalid value for \"which\" attribute "
						"in File element\n";
				rc = 1;
			}
		}
		else if( ! strcmp( attr_name, "name" ) )
		{
			if( filename )
			{
				cerr << "Multiple \"name\" attributes found "
						"in File element\n";
				rc = 1;
			}
			else
			{
				filename = pAttr->Value();

				if( NULL == filename )
				{
					cerr << "Unable to get value of \"name\" attribute\n";
					return 1;
				}
			}
		}
		else
		{
			cerr << "Unrecognized attribute \"" << attr_name
				 << "\" in File element\n";
			return 1;
		}

		pAttr = pAttr->Next();
	} // end for

	if( NULL == filename || '\0' == *filename )
	{
		cerr << "No filename specified in File element\n";
		rc = 1;
	}
	else
	{
		// Expand environmental variables in filename

		filename_str = filename;
		if( expand_env( filename_str ) )
		{
			cerr << "Can\'t expand \"" << filename << "\": "
				 << expand_env_msg() << '\n';
			rc = 1;
		}
	}

	// Make sure that the File element doesn't
	// enclose anything other than comments
	
	const TiXmlNode * pChild = element.FirstChild();
	string text;
	
	while( pChild )
	{
		switch( pChild->Type() )
		{
			case TiXmlNode::ELEMENT :
			{
				cerr << "Unexpected element within File aggregate\n";
				rc = 1;
				break;
			}
			case TiXmlNode::TEXT :
			{
				cerr << "Unexpected text within File aggregate\n";
				rc = 1;
				break;
			}
			case TiXmlNode::COMMENT :
				break;	// ignore comment
			default :
			{
				cerr << "Unexpected content within File aggregate\n";
				rc = 1;
				break;
			}
		} // end switch
		
		pChild = pChild->NextSibling();
	} // end while

	// Construct and load FileRemark, and add it to the list

	if( 0 == rc )
	{
		if( aargh::verbose() )
			cout << "Loaded reference to remark file" << filename_str << '\n';

		auto_ptr< FileRemark > apFile( new FileRemark( home, filename_str.c_str() ) );
		if( apFile->load() )
			rc = 1;
		else
		{
			list.push_back(	apFile.get() );
			apFile.release();  // No exceptions?  Clear auto_ptr...
		}
	}
	
	return rc;
}

/***************************************************************************
 Load a Copyright element into a Copyright; append to the list
 Returns: 0 if successful, non-zero otherwise
 ***************************************************************************/
int get_copyright( const TiXmlElement & element, RemarkList & list )
{
	int rc = 0;
	Remark::Home home = Remark::BOTH;
	bool which_found = false;
	const char * author = NULL;

	const TiXmlAttribute * pAttr = element.FirstAttribute();
	if( NULL == pAttr )
	{
		cerr << "Copyright element has no attributes\n";
		cerr << element << '\n';
		return 1;
	}

	// Loop through the attributes until we have
	// seen them all (or found an error)

	while( pAttr )
	{
		const char * attr_name = pAttr->Name();

		if( NULL == attr_name )
		{
			cerr << "Unable to get attribute name for Copyright element\n";
			return 1;
		}
		else if( ! strcmp( attr_name, "which" ) )
		{
			if( which_found )
			{
				cerr << "Multiple \"which\" attributes found "
						"in Copyright element\n";
				rc = 1;
			}
			which_found = true;

			const char * s = pAttr->Value();

			if( ! s )
			{
				cerr << "Unable to get value of \"which\" attribute "
						"in Copyright element\n";
				return 1;
			}
			else if( ! strcmp( s, "implementation" ) )
			    home = Remark::IMPL;
			else if( ! strcmp( s, "header" ) )
				home = Remark::HDR;
			else if( ! strcmp( s, "both" ) )
				home = Remark::BOTH;
			else
			{
				cerr << "Invalid value for \"which\" attribute "
						"in Copyright element\n";
				rc = 1;
			}
		}
		else if( ! strcmp( attr_name, "author" ) )
		{
			if( author )
			{
				cerr << "Multiple \"author\" attributes found "
					 << "in Copyright element\n";
				rc = 1;
			}
			else
			{
				author = pAttr->Value();

				if( NULL == author )
				{
					cerr << "Unable to get value of \"author\" attribute\n";
					return 1;
				}
			}
		}
		else
		{
			cerr << "Unrecognized attribute \"" << attr_name
				 << "\" in Copyright element\n";
			return 1;
		}

		pAttr = pAttr->Next();
	} // end for

	if( NULL == author || '\0' == *author )
	{
		cerr << "No author specified in Copyright element\n";
		rc = 1;
	}
	
	// Make sure that the File element doesn't
	// enclose anything other than comments
	
	const TiXmlNode * pChild = element.FirstChild();
	string text;
	
	while( pChild )
	{
		switch( pChild->Type() )
		{
			case TiXmlNode::ELEMENT :
			{
				cerr << "Unexpected element within Copyright aggregate\n";
				rc = 1;
				break;
			}
			case TiXmlNode::TEXT :
			{
				cerr << "Unexpected text within Copyright aggregate\n";
				rc = 1;
				break;
			}
			case TiXmlNode::COMMENT :
				break;	// ignore comment
			default :
			{
				cerr << "Unexpected content within Copyright aggregate\n";
				rc = 1;
				break;
			}
		} // end switch
		
		pChild = pChild->NextSibling();
	} // end while

	if( 0 == rc )
	{
		if( aargh::verbose() )
			cout << "Loaded copyright remark for author " << author << '\n';

		auto_ptr< Copyright > apCopy( new Copyright( home, author ) );
		list.push_back(	apCopy.get() );
		apCopy.release();  // No exceptions?  Clear auto_ptr...
	}
	
	return rc;
}

} // end namespace
