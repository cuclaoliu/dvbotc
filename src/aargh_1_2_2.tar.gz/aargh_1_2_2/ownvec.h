/*----------------------------------------------------
 Desc    : Header for OwningVector template class
 Author  : Scott McKellar
 Notes   :

 The OwningVector class is a thin wrapper for std::vector,
 designed to hold pointers to dynamically allocated
 objects.  Objectives:

 1. Provide a destructor that will delete the pointers

 2. Provide exception-safe operations

 Only those operations are provided that currently
 have a use.  More may be added as needed.

 However, if you find yourself adding a lot of
 baroque complications, or if you are tempted to
 create similar wrappers for other container classes,
 consider using something like Boost::shared_ptr for
 a more complete and more elegant solution.

 OwningVector is a simple tool for simple needs
 where the Boost libraries would be overkill.

 Copyright 2006 Scott McKellar
 All Rights reserved
 
 Date       Change
 ---------- -----------------------------------------
 2006/03/06 Initial creation
 ---------------------------------------------------*/

#ifndef OWNVEC_H
#define OWNVEC_H

#include <vector>

template < typename T > class OwningVector
{
	public :

		OwningVector() {};
		~OwningVector() { clear(); }

		// Disable copy constructor and assignment operator by
		// declaring them but not defining them, since we don't
		// want multiple copies of the pointers

		OwningVector< T > ( const OwningVector< T > & other );
		OwningVector< T > & operator=( const OwningVector< T > & other );
		
		bool empty() const { return vec_.empty(); }
		void clear();
		void push_back( T * p );
		void swap( OwningVector< T > & other );
		typename std::vector< T * >::const_iterator begin() const;
		typename std::vector< T * >::const_iterator end() const;
		
	private :

		
		std::vector< T * > vec_;
};

/***************************************************************************
 Delete all the pointers in the vector, then clear the vector
 Returns: nothing
 ***************************************************************************/
template <typename T>
inline void OwningVector< T >::clear()
{
	typename std::vector< T * >::const_iterator iter = vec_.begin();
	typename std::vector< T * >::const_iterator const ending = vec_.end();

	while( iter != ending )
	{
		try
		{
			delete *iter;
		}
		catch( ... )
		{
			;
		}
		
		++iter;
	}

	vec_.clear();
}

/***************************************************************************
 Swap the contents of two OwningVectors of the same type
 Returns: nothing
 ***************************************************************************/
template <typename T>
inline void OwningVector< T >::swap( OwningVector< T > & other )
{
	vec_.swap( other.vec_ );
}

/***************************************************************************
 Append a new pointer to the vector
 Returns: nothing
 ***************************************************************************/
template <typename T>
inline void OwningVector< T >::push_back( T * p )
{
	// We don't populate the new vector entry until we have successfully
	// appended a NULL pointer.  That way we know that if the push_back
	// operation throws an exception, we won't have deleted the new
	// pointer.
	
	vec_.push_back( NULL );
	vec_.back() = p;
}

/***************************************************************************
 Return a const_iterator to the beginning
 Returns: const_iterator into underlying vector
 ***************************************************************************/
template <typename T>
inline typename std::vector< T * >::const_iterator OwningVector< T >::begin() const
{
	return vec_.begin();
}

/***************************************************************************
 Return a const_iterator to the end
 Returns: const_iterator into underlying vector
 ***************************************************************************/
template <typename T>
inline typename std::vector< T * >::const_iterator OwningVector< T >::end() const
{
	return vec_.end();
}

/***************************************************************************
 Swap the contents of two OwningVectors of the same type
 Returns: nothing
 ***************************************************************************/
template <typename T>
inline void swap( OwningVector< T > & ov1, OwningVector< T > & ov2 )
{
	ov1.swap( ov2 );
}

#endif
