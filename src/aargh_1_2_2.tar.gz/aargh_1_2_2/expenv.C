/*----------------------------------------------------
 Desc    : Expand environmental variables within a string,
           using shell-like notation, i.e. replace
           $FOOBAR or ${FOOBAR} with the contents of the
           environmental variable named FOOBAR.
 Author  : Scott McKellar
 Notes   : Use a finite state automaton to parse the text.

 This program is free software; you can redistribute it and/or
 modify it under the terms of version 2 of the GNU General
 Public License as published by the Free Software Foundation.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor,
 Boston, MA  02110-1301, USA.

 Copyright 2006 Scott McKellar
 All Rights reserved
 
 Date       Change
 ---------- -----------------------------------------
 2006/03/19 Initial creation
 ---------------------------------------------------*/

#include <cstdlib>
#include <cctype>
#include <string>
#include <iostream>
#include "expenv.h"

namespace std {};
using namespace std;

namespace {
	
enum
{
	E_LETTER,	// letters and underscores
	E_DIGIT,	// decimal digits
	E_DOLLAR,	// dollar sign
	E_LEFT,		// left curly brace
	E_RIGHT,	// right curly brace
	E_BACK,		// backslash
	E_TILDE,	// tilde
	E_END,		// end of text
	E_OTHER		// none of the above
} event;

string s;	// working buffer
string var;	// for building name of environmental variable
string msg;	// for error messages

int do_curly_var( char c );
int do_var( char c );
int do_left( char c );
int do_tilde( char c );
int do_back( char c );
int do_dollar( char c );
int do_begin( char c );
int do_between( char c );

int ( *handler )( char c );		// Function pointer is state variable

} // end namespace

/***************************************************************************
 Return the most recent error message
 Returns: char pointer to error message
 ***************************************************************************/
const char * expand_env_msg()
{
	return msg.c_str();
}

/***************************************************************************
	Recognize environmental variables and replace them with their values.
	An environmental variable consists of a dollar sign followed by a name.
	The name may be enclosed in curly braces.  The name is a contiguous series
	of letters, underscores, and/or digits, but cannot start with a digit.
 
	Returns: 0 if successful, non-zero otherwise.  If successful, we return
	the expanded text in the string parameter.
 ***************************************************************************/
int expand_env( string & text )
{
	const char * p = text.c_str();
	if( ! p )
	{
		msg = "Null input string!";
		return 1;
	}

	s.clear();

	handler = do_begin;
	unsigned char c;
	int rc = 0;

	do
	{
	// Examine the next character to determine
	// what kind of event it represents

		c = static_cast< unsigned char >( *p );

		if( '\0' == c )
			event = E_END;
		else if( isalpha( c ) || '_' == c )
			event = E_LETTER;
		else if( isdigit( c ) )
			event = E_DIGIT;
		else if( ! isprint( c ) )
		{
			msg = "Unprintable character found in string";
			rc = 1;
		}
		else
		{
			switch( c )
			{
				case '$' :
					event = E_DOLLAR;
					break;
				case '{' :
					event = E_LEFT;
					break;
				case '}' :
					event = E_RIGHT;
					break;
				case '\\' :
					event = E_BACK;
					break;
				case '~' :
					event = E_TILDE;
					break;
				default :
					event = E_OTHER;
					break;
			}
		}

	// Call appropriate state handler

		if( 0 == rc )
			rc = handler( c );
		
		++p;
	} while( c && 0 == rc );

	if( 0 == rc )
		s.swap( text );
	
	return rc;
}

namespace {

/***************************************************************************
 Look up the value of an environmental variable.  If you find it, append it
 to the buffer.  Otherwise complain.
 Returns:
 ***************************************************************************/
int append_var()
{
	const char * p = getenv( var.c_str() );
	if( p )
	{
		s += p;
		return 0;
	}
	else
	{
		msg = "No value found for $";
		msg += var;
		return 1;
	}
}

/***************************************************************************
 We have collected at least one character of a variable name within curly
 braces.  Expect a letter, underscore, digit, or right curly brace.
 Returns: 0 if successful, else 1
 ***************************************************************************/
int do_curly_var( char c )
{
	switch( event )
	{
		case E_LETTER :
		case E_DIGIT :
			var += c;
			break;
		case E_RIGHT :
			if( append_var() )
				return 1;
			else
				handler = do_between;
			break;
		case E_END :
			msg = "Expected right curly brace not found";
			return 1;
		default :
			msg = "Unexpected character \'";
			msg += c;
			msg += "\' within curly braces";
			return 1;
	}
	return 0;
}

/***************************************************************************
 We are collecting characters within a variable name.  Anything other than
 a letter, underscore, or digit terminates the variable name.
 Returns: 0 if successful, else 1
 ***************************************************************************/
int do_var( char c )
{
	switch( event )
	{
		case E_LETTER :
		case E_DIGIT :
			var += c;
			break;
		case E_END :
			return append_var();
		case E_DOLLAR :
			if( append_var() )
				return 1;
			else
				handler = do_dollar;
			break;
		case E_BACK :
			if( append_var() )
				return 1;
			else
				handler = do_back;
			break;
		default :
			if( append_var() )
				return 1;
			else
			{
				s += c;
				handler = do_between;
			}
			break;
	}
	return 0;
}

/***************************************************************************
 We found a dollar sign and a left curly brace.  Expect a letter or
 underscore to start a variable name.
 Returns: 0 if successful, else 1
 ***************************************************************************/
int do_left( char c )
{
	switch( event )
	{
		case E_LETTER :
			var = c;
			handler = do_curly_var;
			break;
		case E_END :
			msg = "Unexpected end of string after left curly brace";
			return 1;
		default :
			msg = "Unexpected character \'";
			msg += c;
			msg += "\' after left curly brace";
			return 1;
	}
	return 0;
}

/***************************************************************************
 We found a tilde at the beginning of the string.  If a slash or end-of-string
 follows, prepend the home directory ($HOME).  Otherwise treat the tilde
 literally.
 Returns: 0 if successful, else 1
 ***************************************************************************/
int do_tilde( char c )
{
	if( '/' == c )
	{
		var = "HOME";
		if( append_var() )
			return 1;
		else
		{
			s += '/';
			handler = do_between;
		}
	}
	else if( '\0' == c )
	{
		var = "HOME";
		return append_var();
	}
	else
	{
		// Treat tilde literally
		
		s += '~';
		s += c;
		handler = do_between;
	}
	
	return 0;
}

/***************************************************************************
 We just saw a backslash.  Expect a dollar sign or another backslash.
 Returns: 0 if successful, else 1
 ***************************************************************************/
int do_back( char c )
{
	switch( event )
	{
		case E_DOLLAR :
		case E_BACK :
		case E_TILDE :
			s += c;
			handler = do_between;
			break;
		case E_END :
			msg = "Unexpected end of string after unescaped backslash";
			return 1;
		default :
			msg = "Unexpected character \'";
			msg += c;
			msg += "\' after unescaped backslash";
			return 1;
	}
	return 0;
}

/***************************************************************************
 We found a dollar sign.  We expect either a left curly brace or the first
 character of a variable name (i.e. letter or underscore).
 Returns: 0 if successful, else 1
 ***************************************************************************/
int do_dollar( char c )
{
	switch( event )
	{
		case E_LETTER :
			var = c;
			handler = do_var;
			break;
		case E_LEFT :
			handler = do_left;
			break;
		case E_END :
			msg = "Unexpected end of string after dollar sign";
			return 1;
		default :
			msg = "Unexpected character \'";
			msg += c;
			msg += "\' after dollar sign";
			return 1;
	}
	return 0;
}

/***************************************************************************
 Respond to a character outside of environmental variables
 Returns: 0 if successful, else 1
 ***************************************************************************/
int do_between( char c )
{
	switch( event )
	{
		case E_DOLLAR :
			handler = do_dollar;
			break;
		case E_BACK :
			handler = do_back;
			break;
		case E_END :
			break;
		default :		// add to buffer
			s += c;
			break;
	}
	return 0;
}

/***************************************************************************
 Begin at the beginning.
 Returns: 0 if successful, else 1
 ***************************************************************************/
int do_begin( char c )
{
	switch( event )
	{
		case E_DOLLAR :
			handler = do_dollar;
			break;
		case E_BACK :
			handler = do_back;
			break;
		case E_TILDE :
			handler = do_tilde;
			break;
		case E_END :		// Empty string?  Oh, well...
			break;
		default :
			s += c;
			handler = do_between;
			break;
	}
	return 0;
}

} // end namespace
