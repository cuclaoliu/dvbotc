/*----------------------------------------------------
 Desc    : Utility function to concatenate a path and
           a file name
 Author  : Scott McKellar
 Notes   : 
 
 This program is free software; you can redistribute it and/or
 modify it under the terms of version 2 of the GNU General
 Public License as published by the Free Software Foundation.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor,
 Boston, MA  02110-1301, USA.

 Copyright 2006 Scott McKellar
 All Rights reserved
 
 Date       Change
 ---------- -----------------------------------------
 2006/04/01 Initial creation
 ---------------------------------------------------*/

#include <string>

namespace std {}
using namespace std;
/***************************************************************************
 Concatenate a directory path and a filename.  Insert a separating slash
 if one is not already present at the end of the path.
 Returns: reference to the receiving string.
 ***************************************************************************/
string & pathname( const string & path, const string & name,
	string & pathname )
{
	string s( path );

	if( s.empty() )
		s = name;
	else if ( name.empty() )
		;		// Huh?  Oh, well...
	else
	{
		// Look for slash at end of path
		
		if( s[ s.size() - 1 ] != '/' )
			s += '/';
		s += name;
	}

	// Return the results
	
	s.swap( pathname );
	return pathname;
}
