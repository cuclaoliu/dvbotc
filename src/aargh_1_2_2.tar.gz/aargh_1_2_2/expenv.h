/*----------------------------------------------------
 Desc    : Header for functions to expand
           environmental variables
 Author  : Scott McKellar
 Notes   :

 Copyright 2006 Scott McKellar
 All Rights reserved
 
 Date       Change
 ---------- -----------------------------------------
 2006/03/24 Initial creation
 ---------------------------------------------------*/

#ifndef EXPENV_H
#define EXPENV_H

int expand_env( std::string & text );
const char * expand_env_msg();

#endif
