/*---------------------------------------------------------------------
 Desc    : Code generator to write C++ header files
		   for Opts class (possibly under a different name)
 Author  : Scott McKellar
 Notes   : 

 Copyright 2006 Scott McKellar
 All rights reserved
 
 This program is free software; you can redistribute it and/or
 modify it under the terms of version 2 of the GNU General
 Public License as published by the Free Software Foundation.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor,
 Boston, MA  02110-1301, USA.

 Date       Change
 ---------- -----------------------------------------------------------
 2005/01/01 Initial creation
 2006/01/07 Add default extension to file name
 2006/01/15 Emit messages in verbose mode
 2006/04/09 Support separate header directory
 --------------------------------------------------------------------*/

#include <cstdlib>
#include <ctime>
#include <string>
#include <map>
#include <vector>
#include <set>
#include <iostream>
#include <fstream>
#include "ownvec.h"
#include "optspec.h"

namespace std {}
using namespace std;

namespace {

#ifndef AARGH_CXX_HDR_EXT
#define AARGH_CXX_HDR_EXT "h"
#endif

const char * default_extension = AARGH_CXX_HDR_EXT;

const char * structure;

void make_guard( const string & filename, string & guard );
int  make_declaration( ostream & out, const OptSpec & spec );

} // end namespace

/***************************************************************************
 Set default extension for C++ source files (or reset to default default)
 Returns: nothing
 ***************************************************************************/
void set_cxx_hdr_ext( const char * ext )
{
	if( ext && *ext )
		default_extension = ext;
	else
		default_extension = AARGH_CXX_HDR_EXT;
}

int cxx_header( const OptSpec & spec )
{
	int rc = 0;

	// Determine the header name, adding an extension as needed
	
	string hdr_name = spec.header();
	if( hdr_name.empty() )
		hdr_name = "opts.h";
	else
	{
		// Find the basename

		const char * basename = strrchr( hdr_name.c_str(), '/' );
		if( basename )
			++basename;
		else
			basename = hdr_name.c_str();

		// If there is no period, add an extension

		if( ! strchr( basename, '.' ) )
		{
			hdr_name += '.';
			hdr_name += default_extension;
		}
	}
	
	string filename;  // For fully qualified file name
	pathname( spec.header_dir(), hdr_name, filename );
	
	ofstream out( filename.c_str() );
	if( out.fail() )
	{
		cerr << "Unable to open output header file "
			 << filename << '\n';
		return 1;
	}

	if( aargh::verbose() )
		cout << "Writing header file " << filename << '\n';
	
	if( spec.structure().empty() )
		structure = "Opts";
	else
		structure = spec.structure().c_str();

	// Write a comment block at the top of the file
	
	if( aargh::hdr_remarks( spec, out ) )
	{
		cerr << "Unable to write comment block\n";
		return 1;
	}

	// Open a compilation guard

	{
		string guard;
		make_guard( filename, guard );

		out << "#ifndef " << guard
			<< "\n#define " << guard << "\n\n";
	}

	const OptMap & map = spec.opt_map();
	const OptMap::const_iterator map_end = map.end();
	OptMap::const_iterator iter = map.begin();

	// Decide whether to #include <string> or <vector>

	bool string_needed = false; // whether to #include <string>
	bool vector_needed = false; // whether to #include <vector>

	while( iter != map_end )
	{
		const Option * pOpt = iter->second;

		if( ! pOpt->single() )
			vector_needed = true;

		if( Option::OPT_STR == pOpt->type() )
			string_needed = true;

		++iter;
	}

	// #include <string> and/or <vector> as needed

	if( string_needed || vector_needed )
	{
		if( string_needed )
			out << "#include <string>\n";

		if( vector_needed )
			out << "#include <vector>\n";

		out << '\n';
	}

	// write the class declaration and prototypes

	rc = make_declaration( out, spec );

	// Close the compilation guard

	out << "\n#endif\n";

	return rc;
}

namespace {

/*---------------------------------------------------------------------
 Desc    : Given a file name, construct a macro name to be used to
		   avoid multiple inclusions.

		   Raise letters to upper case; keep digits and upper case
		   unchanged; change everthing else to an underscore.  Add
		   "_GUARD" at the end.
 Returns : nothing
 --------------------------------------------------------------------*/
void make_guard( const string & filename, string & guard )
{
	const char * s = filename.c_str();

	string temp_guard;

	while( *s )
	{
		char c = static_cast< unsigned char>( *s );
		if( islower( c ) )
			temp_guard += toupper( c );
		else if( isalnum( c ) )
			temp_guard += c;
		else
			temp_guard += '_';

		++s;
	}

	temp_guard += "_GUARD";

	guard.swap( temp_guard );
 }

/*---------------------------------------------------------------------
 Desc    : Write a declaration of the specified class
 Returns : 0 if successful, otherwise 1
 --------------------------------------------------------------------*/
int make_declaration( ostream & out, const OptSpec & spec )
{
	out << "class " << structure << "\n{\n";

    out << "\tpublic :\n\n";

	// Declare constructor and destructor

	out << "\t\t" << structure << "()\n\t\t{\n";
	out << "\t\t\tinitialize();\n";
	out << "\t\t\tpopulated = false;\n";
	out << "\t\t};\n";
	out << "\t\t~" << structure << "() {}\n\n";

	// Declare member function for getting arguments

	const char * func_name;

	if( spec.function().empty() )
		func_name = "get";
	else
		func_name = spec.function().c_str();

	out << "\t\tint " << func_name 
		<< "( int argc, char * argv[] );\n";
	out << "\t\tint new_argc() const { return new_argc_; }\n";
	out << "\t\tchar ** new_argv() const { return new_argv_; }\n\n";

	// Define inline accessor functions

	const OptMap & map = spec.opt_map();
	OptMap::const_iterator iter = map.begin();
	const OptMap::const_iterator map_end = map.end();

	while( iter != map_end )
	{
		const Option * pOpt = iter->second;

		out << "\t\t";
		switch( pOpt->type() )
		{
			case Option::OPT_BOOL :
				out << "bool ";
				break;
			case Option::OPT_INT  :
				if( pOpt->single() )
					out << "unsigned long ";
				else
					out << "const std::vector< unsigned long > &"
						   "\n\t\t\t ";
				break;
			case Option::OPT_STR  :
				if( pOpt->single() )
					out << "const std::string & ";
				else
					out << "const std::vector< std::string > &"
						   "\n\t\t\t ";
				break;
			default       :
				break;
		}

		out << pOpt->name()	<< "() const { return " 
			<< pOpt->name() << "_; }\n";

		// Define boolean accessor for presence/absence

		if( Option::OPT_BOOL != pOpt->type() )
			out << "\t\tbool " << pOpt->name() 
				<< "_found() const { return "
				<< pOpt->name() << "_found_; }\n";

		++iter;
	}

	// Declare private members

    out << "\n\tprivate :\n\n";

	out << "\t\tvoid initialize();\n\n";

	out << "\t\tbool populated;\n";
	out << "\t\tint new_argc_;\n";
	out << "\t\tchar ** new_argv_;\n\n";

	iter = map.begin();

	while( iter != map_end )
	{
		const Option * pOpt = iter->second;

		out << "\t\t";
		switch( pOpt->type() )
		{
			case Option::OPT_BOOL :
				out << "bool ";
				break;
			case Option::OPT_INT  :
				if( pOpt->single() )
					out << "unsigned long ";
				else
					out << "std::vector< unsigned long > ";
				break;
			case Option::OPT_STR  :
				if( pOpt->single() )
					out << "std::string ";
				else
					out << "std::vector< std::string > ";
				break;
			default       :
				break;
		}
		out << pOpt->name() << "_;\n";

		// Add a flag for presence/absence of argument

		if( Option::OPT_BOOL != pOpt->type() )
			out << "\t\tbool " << pOpt->name()
				<< "_found_;\n";

		++iter;
	}

	out << "};\n\n";

	// Declare any validator functions

	// Create a set of function names so that we can
	// avoid declaring the same validator twice

	set< string > func_set;
	pair< set< string >::iterator, bool > set_result;

	iter = map.begin();

	while( iter != map_end )
	{
		const Option * pOpt = iter->second;

		const StringOpt * pStr =
			dynamic_cast< const StringOpt *>( pOpt );

		if( pStr && ! pStr->validator().empty() )
		{
			set_result = func_set.insert( pStr->validator() );
			if( set_result.second )
			{
				// Succeeded in inserting the function name,
				// hence we hadn't inserted it before, hence
				// we haven't declared the function yet,
				// so we can declare it now...

				// if there's a linkage type (other than C++ ),
				// write the linkage specifier

				const string & linkage = pStr->linkage();
				if( linkage.size() > 0 && linkage != "C++" )
					out << "extern \"" << linkage << "\" ";
				
				out << "int " << pStr->validator()
					<< "( const char * arg );\n";
			}
		}

		++iter;
	}

	return 0;
}

} // end namespace
