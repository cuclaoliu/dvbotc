/*---------------------------------------------------------------------
 Desc    : Implementation of Optspec, Option, and related classes
 Author  : Scott McKellar
 Notes   :

 Copyright 2005 Scott McKellar
 All rights reserved

 This program is free software; you can redistribute it and/or
 modify it under the terms of version 2 of the GNU General
 Public License as published by the Free Software Foundation.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor,
 Boston, MA  02110-1301, USA.

 Date       Change
 ---------- -----------------------------------------------------------
 2004/10/10 Initial creation
 --------------------------------------------------------------------*/

#include <climits>
#include <string>
#include <map>
#include <vector>
#include "remark.h"
#include "ownvec.h"
#include "optspec.h"

namespace std {};
using namespace std;

const std::string Option::empty_name;

Option::~Option() {}

BoolOpt::~BoolOpt() {}
Option::OptType BoolOpt::type() const { return OPT_BOOL; }
bool BoolOpt::has_default() const { return false; }

IntOpt::~IntOpt() {}
Option::OptType IntOpt::type() const { return OPT_INT; }
bool IntOpt::has_default() const
{ return single() && (! required()) && ( default_value_ ); }

IntOpt::IntOpt( unsigned long min_val, unsigned long max_val, 
	unsigned long default_arg, const std::string & n )
	: Option( n ), min_( min_val ), max_( max_val ),
	default_value_( default_arg )
{
	// Sanity check

	if( max_ < min_ )
		max_ = min_;  // To do: throw exception?
}

StringOpt::~StringOpt() {}
Option::OptType StringOpt::type() const { return OPT_STR; }
bool StringOpt::has_default() const
{ return single() && (! required()) && (! default_value_.empty()); }

StringOpt::StringOpt( unsigned long min, unsigned long max, 
	const std::string & validator_name,
	const std::string & linkage_name,
	const std::string & default_arg,
	const std::string & n )
	: Option( n ), min_len_( min ), max_len_( max ),
	validator_( validator_name ),
	linkage_( linkage_name ),
	default_value_( default_arg )
{
	// Sanity check

	if( max_len_ < min_len_ )
		max_len_ = min_len_;  // To do: throw exception?
}

/*-------------------------------------------------------------------*/

OptSpec::OptSpec() : min_args_( 0 ), max_args_( ULONG_MAX ) {}

// Destructor: destruct all the Options in the map
OptSpec::~OptSpec()
{
	OptMap::iterator iter = opt_map_.begin();
	OptMap::iterator end  = opt_map_.end();

	while( iter != end )
	{
		delete iter->second;
		++iter;
	}
}
