/*----------------------------------------------------
 Desc    : Read and parse XML file to get specification of how
		   to parse the command line
 Author  : Scott McKellar
 Notes   : Uses tinyxml library

 Copyright 2005 Scott McKellar
 All rights reserved
 
 This program is free software; you can redistribute it and/or
 modify it under the terms of version 2 of the GNU General
 Public License as published by the Free Software Foundation.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor,
 Boston, MA  02110-1301, USA.

 Date       Change
 ---------- -----------------------------------------
 2004/10/02 Initial creation
 2006/01/15 Tidy up verbose messages
 2006/01/21 Accept linkage attribute on Validator
 2006/01/28 Accept default attribute for StringOpt
 2006/02/18 Accept default attribute for IntOpt
 2006/03/25 Expand environmental variables in
            header and module names
 2006/04/01 Accept directory attribute in Header element
 ---------------------------------------------------*/
#include <cstdlib>
#include <cerrno>
#include <cstdio>
#include <climits>
#include <cctype>
#include <cstring>
#include <string>
#include <vector>
#include <memory>
#include <stdexcept>
#include <iostream>
#include <map>
#include <tinyxml.h>
#include "remark.h"
#include "ownvec.h"
#include "expenv.h"
#include "optspec.h"

namespace std {};
using namespace std;

namespace aargh
{
	int get_remarks( const TiXmlElement & aggregate, RemarkList & list );
}

namespace {
	
int load_options( const TiXmlElement & element, OptMap & map );
int get_validator( const TiXmlElement & element,
  string & name, string & linkage );
int get_option_attributes( const TiXmlElement & element,
								  char & letter, string & name, string & def_val );
int get_int_attributes( const TiXmlElement & element,
								  char & letter, string & name, unsigned long & def_val );
int get_bool_attributes( const TiXmlElement & element,
	char & letter, string & name );
bool is_letter( const char * s );
bool is_name( const char * s );
bool is_simple( const TiXmlElement & element );
int get_minmax( const TiXmlElement & element,
	unsigned long & min, unsigned long & max );
int get_name_only( const TiXmlElement & element,
	string & name );
int get_header( const TiXmlElement & element,
	string & name, string & dir );
auto_ptr< const Option > make_bool( const TiXmlElement & node,
	const string & name );
auto_ptr< const Option > make_int( const TiXmlElement & node,
	const string & name, unsigned long default_value );
auto_ptr< const Option > make_string( const TiXmlElement & node,
	const string & name, const string & default_arg );

} // end namespace

/*----------------------------------------------------
 Desc    : Read XML stream, parse it for specification
		   of command line parsing
 Returns : 0 if successful, 1 if not
 ---------------------------------------------------*/
int OptSpec::load( std::istream & in )
{
	int rc = 0;

	// Load the XML file

	TiXmlDocument doc;

	// Preserve white space in user-defined remarks
	
	TiXmlBase::SetCondenseWhiteSpace( false );

	in >> doc;
	if( doc.Error() )
	{
		cerr << "Error loading XML";

		int row = doc.ErrorRow();
		if( row )
			cerr << " at line " << row;
		cerr << ": ";

		cerr << doc.ErrorDesc() << '\n';

		return 1;
	}

	// Find the root element, and
	// make sure it has the right name

	TiXmlElement * pRoot = doc.RootElement();
	if( ! pRoot )
	{
		cerr << "No XML found\n";
		return 1;
	}

	if( strcmp( pRoot->Value(), "Spec" ) )
	{
		cerr << "Invalid root element; should be named \"Spec\""
				" instead of \"" << pRoot->Value() << "\"\n";
		return 1;
	}

	// Declare some temporary surrogates
	// for the data members of OptSpec:

	unsigned long min_args = 0;
	unsigned long max_args = ULONG_MAX;
	string structure;
	string header;
	string hdr_dir;
	string module;
	string function;
	OptMap opt_map;
	RemarkList remlist;

	// Use booleans to detect whether or not
	// have seen certain elements

	bool argcount_found = false;
	bool options_found  = false;
	bool structure_found = false;
	bool header_found = false;
	bool module_found = false;
	bool function_found = false;
	bool remarks_found = false;

	// Process each child node in turn

	const TiXmlNode * pChild = pRoot->FirstChild();

	while( pChild && 0 == rc )
	{
		switch( pChild->Type() )
		{
			case TiXmlNode::ELEMENT :
			{
				// Downcast node ptr to element pointer

				const TiXmlElement * pElement =
					pChild->ToElement();
				if( ! pElement )
				{
					cerr << "Internal error: unable to convert "
							"node pointer to element pointer\n";
					return 1;
				}

				const char * value = pElement->Value();

				if( ! strcmp( value, "Options" ) )
				{
					if( options_found )
					{
						cerr << "More than one Options element found\n";
						return 1;
					}

					options_found = true;
					rc = load_options( *pElement, opt_map );
				}
				else if( ! strcmp( value, "Argcount" ) )
				{
					if( argcount_found )
					{
						cerr << "More than one Argcount element found\n";
						return 1;
					}

					argcount_found = true;
					rc = get_minmax( *pElement, min_args, max_args );
				}
				else if( ! strcmp( value, "Structure" ) )
				{
					if( structure_found )
					{
						cerr << "More than one Structure element found\n";
						return 1;
					}

					structure_found = true;

					rc = get_name_only( *pElement, structure );
				}
				else if( ! strcmp( value, "Header" ) )
				{
					if( header_found )
					{
						cerr << "More than one Header element found\n";
						return 1;
					}

					header_found = true;

					rc = get_header( *pElement, header, hdr_dir );
					if( 0 == rc )
					{
						if( expand_env( header ) )
						{
							cerr << "Unable to expand header name \"" << header
								 << "\": " << expand_env_msg() << '\n';
							rc = 1;
						}
						if( expand_env( hdr_dir ) )
						{
							cerr << "Unable to expand header directory \""
								 << hdr_dir << "\": " << expand_env_msg() << '\n';
							rc = 1;
						}
					}
				}
				else if( ! strcmp( value, "Module" ) )
				{
					if( module_found )
					{
						cerr << "More than one Module element found\n";
						return 1;
					}

					module_found = true;
					rc = get_name_only( *pElement, module );
					if( 0 == rc && expand_env( module ) )
					{
						cerr << "Unable to expand module name \"" << module
								<< "\": " << expand_env_msg() << '\n';
						rc = 1;
					}
				}
				else if( ! strcmp( value, "Function" ) )
				{
					if( function_found )
					{
						cerr << "More than one Function element found\n";
						return 1;
					}

					function_found = true;

					rc = get_name_only( *pElement, function );
				}
				else if( !strcmp( value, "Remarks" ) )
				{
					if( remarks_found )
					{
						cerr << "More than one Remarks element found\n";
						return 1;
					}

					remarks_found = true;

					rc = aargh::get_remarks( *pElement, remlist );
				}
				else
				{
					cerr << "Invalid element name: " 
						 << value << '\n';
					return 1;
				}
				break;
			}
			case TiXmlNode::TEXT :
				cerr << "Unexpected text within Spec aggregate: \""
					 << pChild->Value() << "\"\n";
				return 1;

			default  :  // ignore other types of nodes
				break;
		}

		pChild = pChild->NextSibling();
	}

	if( ! options_found && 0 == rc )
	{
		cerr << "No Options element found\n";
		rc = 1;
	}

	if( 0 == rc )
	{
		// Populate the Optspec

		min_args_ = min_args;
		max_args_ = max_args;
		structure_.swap( structure );
		header_.swap( header );
		header_dir_.swap( hdr_dir );
		module_.swap( module );
		function_.swap( function );
		opt_map_.swap( opt_map );
		swap( remark_list_, remlist );
	}
	
	return rc;
}

namespace {
	
/*---------------------------------------------------------------------
 Desc    : Fetches max and min attributes from <Argcount>, applying
		   defaults where attributes are not present
 Returns : 0 if successful, otherwise 1
 --------------------------------------------------------------------*/
int get_minmax( const TiXmlElement & element,
	unsigned long & min, unsigned long & max )
{
	// Make sure there aren't any unexpected attributes

	const TiXmlAttribute * pAttr = element.FirstAttribute();
	while( pAttr )
	{
		const char * attr_name = pAttr->Name();
		if( NULL == attr_name )
		{
			cerr << "Internal error: cannot fetch attribute name\n";
			return 1;
		}
		else if( ! strcmp( attr_name, "min" ) ||
				 ! strcmp( attr_name, "max" ) )
			; // That's fine; do nothing
		else
		{
			cerr << "Invalid attribute " << attr_name 
				 << " found for " << element.Value()
				 << " element\n";
			return 1;
		}

		pAttr = pAttr->Next();
	}

	int rc = 0;
	unsigned long local_min = 0;
	bool min_found = false;

	const char * num_str = element.Attribute( "min" );
	if( num_str )
	{
		min_found = true;
		
		// skip leading white space; check for negative
		
		while( isspace( (unsigned char) *num_str ) )
			++num_str;

		if( '-' == *num_str )
		{
			cerr << "Negative value for \"min\" attribute\n";
			rc = 1;
		}
		else
		{
			// Convert to numeric value
			
			errno = 0;
			char * tail;
			local_min = strtoul( num_str, &tail, 10 );
			if( *tail )
			{
				cerr << "Invalid or non-numeric value for "
						"\"min\" attribute\n";
				rc = 1;
			}
			else if( errno != 0 )
			{
				cerr << "Too large a value for \"min\" attribute\n";
				rc = 1;
			}
		}
	}

	unsigned long local_max = ULONG_MAX;
	bool max_found = false;

	num_str = element.Attribute( "max" );
	if( num_str )
	{
		max_found = true;
		
		// skip leading white space; check for negative
		
		while( isspace( (unsigned char) *num_str ) )
			++num_str;

		if( '-' == *num_str )
		{
			cerr << "Negative value for \"max\" attribute\n";
			rc = 1;
		}
		else
		{
			// Convert to numeric value
			
			errno = 0;
			char * tail;
			local_max = strtoul( num_str, &tail, 10 );
			if( *tail )
			{
				cerr << "Invalid or non-numeric value for "
						"\"max\" attribute\n";
				rc = 1;
			}
			else if( errno != 0 )
			{
				cerr << "Too large a value for \"max\" attribute\n";
				rc = 1;
			}
		}
	}

	if( 0 == rc && min_found && max_found && local_max < local_min )
	{
		cerr << "max = " << local_max << '\n';
		cerr << "min = " << local_min << '\n';
		cerr << "Value of \"max\" attribute must not be less "
				"than the value of \"min\" attribute\n";
		rc = 1;
	}

	if( 0 == rc )
	{
		min = local_min;
		max = local_max;
	}

	return rc;
}

/*---------------------------------------------------------------------
 Desc    : Fetch name attribute from a specified element.  There
		   must be exactly one attribute, named "name".
 Returns : 0 if successful, otherwise 1
 --------------------------------------------------------------------*/
int get_name_only( const TiXmlElement & element,
	string & name )
{
	const TiXmlAttribute * pAttr = element.FirstAttribute();
	if( NULL == pAttr )
	{
		cerr << element.Value()
			 << " element has no name specified\n";
		return 1;
	}

	const char * s = pAttr->Name();

	// Check name of first attribute

	if( ! s || ! *s )
	{
		cerr << "Name of attribute is empty on "
			 << element.Value() << " element\n";
		return 1;
	}

	if( strcmp( s, "name" ) )
	{
		cerr << "Invalid attribute on " << element.Value()
			 << " elemement: " << s << '\n';
	}

	const char * value = pAttr->Value();
	if( ! value || ! *value )
	{
		cerr << "Value of name attribute is empty on "
			 << element.Value() << " element\n";
		return 1;
	}

	// Make sure there is no other attribute

	pAttr = pAttr->Next();
	if( pAttr )
	{
		const char * bad_attr = pAttr->Name();
		if( ! bad_attr )
			bad_attr = "";
		cerr << "Unexpected attribute " << bad_attr
			 << " on " << element.Value() << " element\n";
		return 1;
	}

	// So far so good; return the results

	name = value;
	return 0;
}

/*---------------------------------------------------------------------
 Desc    : Fetch name and directory attributes from Header element.
 Returns : 0 if successful, otherwise 1
 --------------------------------------------------------------------*/
int get_header( const TiXmlElement & element,
	 string & name, string & dir )
{
	int rc = 0;
	string name_value;
	string dir_value;
	
	const TiXmlAttribute * pAttr = element.FirstAttribute();
	
	while( pAttr )
	{
		const char * attr_name = pAttr->Name();
		if( ! attr_name )
		{
			cerr << "Unable to fetch attribute name in Header element\n";
			rc = 1;
			break;
		}

		if( ! strcmp( attr_name, "name" ) )
		{
			const char * s = pAttr->Value();
			if( !s || ! *s )
			{
				cerr << "Specified header name is empty\n";
				rc = 1;
			}
			else
				name_value = s;
		}
		else if( ! strcmp( attr_name, "directory" ) )
		{
			const char * s = pAttr->Value();
			if( !s )
			{
				cerr << "Unable to fetch directory name\n";
				return 1;
			}
			else
				dir_value = s;
		}
		else
		{
			cerr << "Unexpected attribute \"" << attr_name
				 << "\" found in Header element\n";
			rc = 1;
		}
			
		pAttr = pAttr->Next();
	}

	if( 0 == rc )
	{
		if( aargh::verbose() )
		{
			cout << "Found header element";
			if( ! name_value.empty() )
				cout << " for <" << name_value << ">";
			if( ! dir_value.empty() )
				cout << "; directory " << dir_value;
			cout << '\n';
		}
		
		// return the results
		
		name_value.swap( name );
		dir_value.swap( dir );
	}

	return rc;
}

/*---------------------------------------------------------------------
 Desc    : Parse an Options aggregate, loading the resulting
		   Options into an OptMap
 Returns : 0 if successful, otherwise 1
 --------------------------------------------------------------------*/
int load_options( const TiXmlElement & element, OptMap & map )
{
	const TiXmlNode * pChild = element.FirstChild();
	char letter;
	string name;
	string def_val;  // for capturing default values

	const TiXmlAttribute * pAttr = element.FirstAttribute();
	if( pAttr != NULL )
	{
		cerr << "No attributes permitted for Options element\n";
		return 1;
	}

	// Process each child node in turn
 
	while( pChild )
	{
		const TiXmlElement * pElement = pChild->ToElement();
		if( NULL == pElement )
		{
			cerr << "Non-element found within Options element\n";
			return 1;
		}

		auto_ptr< const Option > newOpt;

		const char * value = pElement->Value();

		if( ! strcmp( "BoolOpt", value ) )
		{
			name.erase();
			if( ! get_bool_attributes( *pElement, letter, name ) )
			{
				auto_ptr< const Option > new_bool(
					make_bool( *pElement, name ) );
				if( NULL == new_bool.get() )
					return 1;    // Can't build BoolOpt

				newOpt.reset( new_bool.release() );
			}
			else
				return 1;

			if( aargh::verbose() )
				cout << '-' << letter << " option: \""
					 << name << "\" (takes no argument)\n";
		}
		else if( ! strcmp( "IntOpt", value ) )
		{
			unsigned long def_integer = 0;
			
			name.erase();
			if( ! get_int_attributes( *pElement, letter, name, def_integer ) )
			{
				auto_ptr< const Option > new_int(
					make_int( *pElement, name, def_integer ) );
				if( NULL == new_int.get() )
					return 1;	// Can't build IntOpt

				newOpt.reset( new_int.release() );
			}
			else
				return 1;

			if( aargh::verbose() )
			{
				cout << '-' << letter << " option: \""
					 << name << "\" (takes integer argument)\n";

				if( newOpt->required() )
					cout << "\tRequired\n";

				if( ! newOpt->single() )
					cout << "\tMultiples allowed\n";

				const IntOpt * pInt =
						dynamic_cast< const IntOpt * >( newOpt.get() );
				
				if( pInt->min() > 0 || pInt->max() < ULONG_MAX )
					cout << "\tRange " << pInt->min() << " - "
						 << pInt->max() << '\n';
			}
		}
		else if( ! strcmp( "StringOpt", value ) )
		{
			name.erase();
			def_val.erase();
			if( ! get_option_attributes( *pElement, letter, name, def_val ) )
			{
				auto_ptr< const Option > new_str(
					make_string( *pElement, name, def_val ) );
				if( NULL == new_str.get() )
					return 1;	// Can't build StringOpt

				newOpt.reset( new_str.release() );
			}
			else
				return 1;

			if( aargh::verbose() )
			{
				cout << '-' << letter << " option: \""
					 << name << "\" (takes string argument)\n";

				if( newOpt->required() )
					cout << "\tRequired\n";

				if( ! newOpt->single() )
					cout << "\tMultiples allowed\n";

				const StringOpt * pString =
					dynamic_cast< const StringOpt * >( newOpt.get() );
				
				if( pString->min_len() > 0 || pString->max_len() < ULONG_MAX )
					cout << "\tLength " << pString->min_len() << " - "
						 << pString->max_len() << '\n';

				if( pString->has_default() )
				{
					cout << "\tDefault value: \""
						 << pString->default_value() << "\"\n";
				}
				
				if( pString->validator().size() > 0 )
				{
					cout << "\tValidated by " << pString->validator() << "()";
					if( pString->linkage().size() > 0 )
						cout << ", linkage type \"" << pString->linkage() << '\"';
					cout << '\n';
				}
			}
		}
		else
		{
			cerr << "Invalid option type: \""
				 << value << "\"\n";
			return 1;
		}

		// If we have an option, and no duplication,
		// then add it to the map

		if( newOpt.get() )
		{
			// Make sure we don't already have an option 
			// for the same option letter

			OptMap::const_iterator iter = map.begin();
			const OptMap::const_iterator map_end = map.end();
			
			iter = map.begin();
			while( iter != map_end )
			{
				// Check for duplication of letter or name
				
				if( iter->first == letter )
				{
					cerr << "Multiple options for option letter \'"
							<< letter << "\'\n";
					newOpt.reset();
					return 1;   // entry already exists for this letter

				}
				else
				{
					const Option * pOpt = iter->second;
					if( NULL == pOpt )
					{
						cerr << "Fatal error in load_options(): "
								<< "null pointer to Option" << endl;
						newOpt.reset();
						return 1;

					}

					if( pOpt->name() == name )
					{
							cerr << "Multiple options with same name \""
								 << name << "\"\n";
							newOpt.reset();
							return 1;
					}

				}
				++iter;
			}

			// No duplications; add to map

			map.insert( pair< const char, const Option * >
					( letter, newOpt.get() ) );
			( void ) newOpt.release();

		}

		pChild = pChild->NextSibling();
	}

	return 0;
}

/*---------------------------------------------------------------------
 Desc    : Create a BoolOpt from an XML aggregate
 Returns : auto_ptr to newly allocate BoolOpt if successful, or
		   NULL if not
 --------------------------------------------------------------------*/
auto_ptr< const Option > make_bool( const TiXmlElement & node,
	const string & name )
{
	BoolOpt * pBool = NULL;
	
	if( node.FirstChild() )
		cerr << "No child elements allowed under BoolOpt\n";
	else
		pBool = new BoolOpt( name );

	return auto_ptr< const Option >( pBool );
}

/*---------------------------------------------------------------------
 Desc    : Create a IntOpt from an XML aggregate
 Returns : auto_ptr to newly allocated IntOpt if successful, or
		   NULL if not
 --------------------------------------------------------------------*/
auto_ptr< const Option > make_int( const TiXmlElement & node,
	const string & name, unsigned long default_value )
{
	auto_ptr< IntOpt > newOpt;
	bool successful = true;
	bool required = false;
	bool single = true;
	bool range_found = false;
	unsigned long min = 0;
	unsigned long max = ULONG_MAX;

	const TiXmlNode * pChild = node.FirstChild();
	while( pChild )
	{
		// Loop through child elements

		const TiXmlElement * pElement = pChild->ToElement();
		if( NULL == pElement )
		{
			cerr << "Non-element found within IntOpt element\n";
			successful = false;
		}

		const char * value = pElement->Value();

		if( ! strcmp( "Required", value ) )
		{
			// Make sure Required element is simple;
			// i.e. no attributes or child nodes

			if( is_simple( *pElement ) )
				required = true;
			else
				successful = false;
		}
		else if( ! strcmp( "Multiple", value ) )
		{
			// Make sure Multiple element is simple;
			// i.e. no attributes or child nodes

			if( is_simple( *pElement ) )
				single = false;
			else
				successful = false;
		}
		else if( ! strcmp( "Range", value ) )
		{
			// After checking for duplicates,
			// get min, max of range

			if( range_found )
			{
				cerr << "Multiple Range elements found\n";
				successful = false;
			}
			else 
			{
				range_found = true;
				if( get_minmax( *pElement, min, max ) )
					successful = false;
			}
		}
		else
		{
			cerr << "Unexpected element \"" << value
				 << "\" within IntOpt element\n";
			successful = false;
		}

		pChild = pChild->NextSibling();
	}

	if( successful )
	{
		newOpt = auto_ptr< IntOpt >( new IntOpt( min, max, default_value, name ) );

		if( required )
			newOpt->require();

		if( ! single )
			newOpt->allow_multiples();
	}

	return auto_ptr< const Option >( newOpt.release() );
}

/*---------------------------------------------------------------------
 Desc    : Create a StringOpt from an XML aggregate
 Returns : auto_ptr to newly allocated StringOpt if successful, or
		   NULL if not
 --------------------------------------------------------------------*/
auto_ptr< const Option > make_string( const TiXmlElement & node,
	const string & name, const string & default_arg )
{
	bool successful = true;
	bool required = false;
	bool single = true;
	bool length_found = false;
	bool validator_found = false;
	unsigned long min = 0;
	unsigned long max = ULONG_MAX;
	string validator;
	string linkage;   // fetched but not yet stored

	const TiXmlNode * pChild = node.FirstChild();
	while( pChild )
	{
		// Loop through child elements

		const TiXmlElement * pElement = pChild->ToElement();
		if( NULL == pElement )
		{
			cerr << "Non-element found within StringOpt element\n";
			successful = false;
		}

		const char * value = pElement->Value();

		if( ! strcmp( "Required", value ) )
		{
			// Make sure Required element is simple;
			// i.e. no attributes or child nodes

			if( is_simple( *pElement ) )
				required = true;
			else
				successful = false;
		}
		else if( ! strcmp( "Multiple", value ) )
		{
			// Make sure Multiple element is simple;
			// i.e. no attributes or child nodes

			if( is_simple( *pElement ) )
				single = false;
			else
				successful = false;
		}
		else if( ! strcmp( "Length", value ) )
		{
			// After checking for duplicates,
			// get min, max of range

			if( length_found )
			{
				cerr << "Multiple Length elements found\n";
				successful = false;
			}
			else 
			{
				length_found = true;
				if( get_minmax( *pElement, min, max ) )
					successful = false;
			}
		}
		else if( ! strcmp( "Validator", value ) )
		{
			// After checking for duplicates,
			// get the name of the validator function

			if( validator_found )
			{
				cerr << "Multiple Validator elements found\n";
				successful = false;
			}
			else 
			{
				validator_found = true;
				if( get_validator( *pElement, validator, linkage ) )
				{
					cerr << "Unable to get name and linkage for Validator\n";
					successful  = false;
							
				}
			}
		}
		else
		{
			cerr << "Unexpected element \"" << value
				 << "\" within StringOpt element\n";
			successful = false;
		}

		pChild = pChild->NextSibling();
	} // end while

	if( ! default_arg.empty() )
	{
		if( required || ! single )
		{
			cerr << "Warning: default attribute has no effect when "
					"option is required, or allows multiples\n";
		} 
	}
	
	// Construct a StringOpt and return an auto_ptr to it
	
	auto_ptr< StringOpt > newOpt;

	if( successful )
	{
		newOpt = auto_ptr< StringOpt >(
			new StringOpt( min, max, validator, linkage, default_arg, name ) );

		if( required )
			newOpt->require();

		if( ! single )
			newOpt->allow_multiples();
	}

	return auto_ptr< const Option >( newOpt.release() );
}

/*---------------------------------------------------------------------
 Desc    : Given a Validator element, extract the name and linkage
		   attributes.

		   The pedantically correct OO thing to do is to define a
		   Validator class, with a name and a linkage, and put a
		   Validator member into StringOption.  For now, at least,
		   we won't bother.  The name and linkage of the validator
		   function are members of StringOption.
 Returns : 0 if successful, 1 if not
 --------------------------------------------------------------------*/
int get_validator( const TiXmlElement & element,
						  string & name, string & linkage )
{
	const TiXmlAttribute * pAttr = element.FirstAttribute();
	if( NULL == pAttr )
	{
		cerr << "Validator element has no name or linkage specified\n";
		cerr << element << '\n';
		return 1;
	}

	const char * temp_name;
	const char * temp_linkage = "";

	bool name_found = false;
	bool linkage_found = false;
	
	// Loop through the attributes until we have
	// seen them all (or found an error)

	for( ;; )
	{
		const char * attr_name = pAttr->Name();

		if( NULL == attr_name )
		{
			cerr << "Unable to get attribute name for Validator\n";
			return 1;
		}
		else if( ! strcmp( attr_name, "name" ) )
		{
			if( name_found )
			{
				cerr << "Multiple names found for Validator\n";
				return 1;
			}
			name_found = true;
			
			const char * val = pAttr->Value();

			if( ! val || ! *val )
			{
				cerr << "Validator name is empty\n";
				return 1;
			}

			temp_name = val;
		}
		else if( ! strcmp( attr_name, "linkage" ) )
		{
			if( linkage_found )
			{
				cerr << "Multiple linkage attributes found "
						"for Validator\n";
				return 1;
			}
			linkage_found = true;

			const char * val = pAttr->Value();

			if( val && *val )
				temp_linkage = val;
		}
		else
		{
			cerr << "Unrecognized attribute \"" << attr_name
					<< "\" in Validator element\n";
			return 1;
		}
		
		pAttr = pAttr->Next();
		if( NULL == pAttr )
			break;
	}

	if( ! name_found )
	{
		cerr << "No name found for validator function\n";
		return 1;
	}

	// For exception safety we construct local strings and then, if no
	// exception occurs, swap them with the string parameters.
	
	string name_string( temp_name );
	string linkage_string( temp_linkage );

	name.swap( name_string );
	linkage.swap( linkage_string );
		
	return 0;
}

/*---------------------------------------------------------------------
 Desc    : Given an element representing a boolean option, extract the
		   letter and name attributes.
 Returns : 0 if successful, 1 if not
 --------------------------------------------------------------------*/
int get_bool_attributes( const TiXmlElement & element,
	char & letter, string & name )
{
	const TiXmlAttribute * pAttr = element.FirstAttribute();
	if( NULL == pAttr )
	{
		cerr << "Option element has no letter or name specified\n";
		cerr << element << '\n';
		return 1;
	}

	char temp_letter;
	const char * temp_name;

	bool letter_found = false;
	bool name_found = false;

	// Loop through the attributes until we have
	// seen them all (or found an error)

	for( ;; )
	{
		const char * attr_name = pAttr->Name();

		if( NULL == attr_name )
		{
			cerr << "Unable to get attribute name in option element\n";
			return 1;
		}
		else if( ! strcmp( attr_name, "letter" ) )
		{
			if( letter_found )
			{
				cerr << "Multiple letter attributes in option element\n";
				return 1;
			}
			letter_found = true;

			const char * val = pAttr->Value();

			if( is_letter( val ) )
				temp_letter = *val;
			else
				return 1;
		}
		else if( ! strcmp( attr_name, "name" ) )
		{
			if( name_found )
			{
				cerr << "Multiple name attributes in option element\n";
				return 1;
			}
			name_found = true;

			const char * val = pAttr->Value();

			if( is_name( val ) )
				temp_name = val;
			else
				return 1;
		}
		else
		{
			cerr << "Unexpected attribute \"" << attr_name
					<< " \" on option element\n";
			return 1;
		}

		pAttr = pAttr->Next();
		if( NULL == pAttr )
			break;
	}

	if( ! letter_found )
	{
		cerr << "No letter specified for option\n";
		return 1;
	}

	letter = temp_letter;

	if( name_found )
		name   = temp_name;

	return 0;
}

/*---------------------------------------------------------------------
 Desc    : Given an element representing a boolean option, extract the
		   letter, name, and default attributes.
 Returns : 0 if successful, 1 if not
 --------------------------------------------------------------------*/
int get_int_attributes( const TiXmlElement & element,
	char & letter, string & name, unsigned long & def_val )
{
	string def_string;

	if( get_option_attributes( element, letter, name, def_string ) )
	   return 1;

	if( def_string.empty() )
	{
		def_val = 0L;
		return 0;
	}
	else
	{
		const char * s = def_string.c_str();

		if( !s )
			s = "0";  // shouldn't happen
			
		while( isspace( *s ) )
			++s;

		// Guard against negative values

		if( '-' == *s )
		{
			cerr << "Negative default value not allowed "
					"for integer option\n";
			return 1;
		}
		
		// Convert string to numeric value

		char * tail;

		errno = 0;
        unsigned long val = strtoul( s, &tail, 10 );
		
		if(  *tail != '\0' )
		{
			cerr << "Invalid or non-numeric default value "
					"for integer argument\n";
			return 1;
		}
		else if( errno != 0 )
		{
			cerr << "Too large a default value "
					"for integer argument\n";
			return 1;
		}
		else
		{
			def_val = val;
			return 0;
		}
	}
}

/*---------------------------------------------------------------------
 Desc    : Given an element representing a boolean option, extract the
		   letter, name, and default attributes.
 Returns : 0 if successful, 1 if not
 --------------------------------------------------------------------*/
int get_option_attributes( const TiXmlElement & element,
	char & letter, string & name, string & def_val )
{
	const TiXmlAttribute * pAttr = element.FirstAttribute();
	if( NULL == pAttr )
	{
		cerr << "Option element has no letter or name specified\n";
		cerr << element << '\n';
		return 1;
	}

	char temp_letter;
	const char * temp_name;
	const char * temp_default = "";

	bool letter_found = false;
	bool name_found = false;
	bool default_found = false;

	// Loop through the attributes until we have
	// seen them all (or found an error)

	for( ;; )
	{
		const char * attr_name = pAttr->Name();

		if( NULL == attr_name )
		{
			cerr << "Unable to get attribute name in option element\n";
			return 1;
		}
		else if( ! strcmp( attr_name, "letter" ) )
		{
			if( letter_found )
			{
				cerr << "Multiple letter attributes in option element\n";
				return 1;
			}
			letter_found = true;

			const char * val = pAttr->Value();

			if( is_letter( val ) )
				temp_letter = *val;
			else
				return 1;
		}
		else if( ! strcmp( attr_name, "name" ) )
		{
			if( name_found )
			{
				cerr << "Multiple name attributes in option element\n";
				return 1;
			}
			name_found = true;

			const char * val = pAttr->Value();

			if( is_name( val ) )
				temp_name = val;
			else
				return 1;
		}
		else if( ! strcmp( attr_name, "default" ) )
		{
			if( default_found )
			{
				cerr << "Multiple default attributes in option element\n";
				return 1;
			}
			default_found = true;

			const char * val = pAttr->Value();

			if( val )
				temp_default = val;
			else
			{
				cerr << "Internal error: null pointer to default value\n";
				return 1;
			}
		}
		else
		{
			cerr << "Unexpected attribute \"" << attr_name
				 << " \" on option element\n";
			return 1;
		}

		pAttr = pAttr->Next();
		if( NULL == pAttr )
			break;
	}

	if( ! letter_found )
	{
		cerr << "No letter specified for option\n";
		return 1;
	}

	letter = temp_letter;

	// We use a temporary local string for exception safety
	
	string def_str( temp_default );
	
	if( name_found )
		name = temp_name;

	def_val.swap( def_str );

	return 0;
}

/*---------------------------------------------------------------------
 Desc    : Decide if a nul-terminated string represents a letter
		   (or, as a special exception, a hyphen)
 Returns : true if it is a letter or question mark, else false
 --------------------------------------------------------------------*/
bool is_letter( const char * s )
{
	if( !s || !*s )
	{
		cerr << "Letter value is empty\n";
		return false;
	}

	if( s[ 1 ] )
	{
		cerr << "Letter value contains multiple characters\n";
		return false;
	}

	if( isalpha( (unsigned char) *s ) || '-' == *s )
		return true;
	else
	{
		cerr << "Letter value is not alphabetic or hyphen\n";
		return false;
	}
}

/*---------------------------------------------------------------------
 Desc    : Determine whether a string is suitable as a name.  I.e.
		   the first character must be a letter, and the rest must
		   be letters, digits, or underscores.
 Returns : true if suitable as a name, else false
 --------------------------------------------------------------------*/
bool is_name( const char * s )
{
	if( ! s || ! *s )
	{
		cerr << "Option name is empty\n";
		return false;
	}

	if( ! isalpha( (unsigned char) *s ) )
	{
		cerr << "Option name does not start with a letter\n";
		return false;
	}

	++s;
	while( *s )
	{
		if( isalnum( (unsigned char) *s ) || '_' == *s )
			++s;
		else
		{
			cerr << "Invalid character \"" << *s
				 << "\" within option name\n";
			return false;
		}
	}

	return true;
}

/*---------------------------------------------------------------------
 Desc    : Decide if an element is simple, i.e. if it has no 
		   attributes or child nodes
 Returns : true if simple, else false
 --------------------------------------------------------------------*/
bool is_simple( const TiXmlElement & element )
{
	bool rc = true;
	const TiXmlBase * p = element.FirstAttribute(); 
	if( p )
	{
		cerr << "Attribute not allowed for "
			 << element.Value() << " element\n";
		rc = false;
	}

	p = element.FirstChild();
	if( p )
	{
		cerr << "Child node not allowed for "
			 << element.Value() << " element\n";
		rc = false;
	}

	return rc;
}

} // end namespace
